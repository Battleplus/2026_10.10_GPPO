"""Read-only audit of the actual consumed R10 transfer failure."""
import copy
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path

ROOT = Path('E:/10.14')
PREP = ROOT / 'n2-development/hosted-preparation-evidence'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    approved_path = PREP / 'controller-config-approved-r10-password-20261015.json'
    proposed_path = PREP / 'controller-config-proposed-r10-password-20261015.json'
    auth_path = PREP / 'controller-authorization-r10-password-20261015.json'
    human_path = PREP / 'human-approval-r10-password-20261015.json'
    approved = json.loads(approved_path.read_text(encoding='utf-8'))
    proposed = json.loads(proposed_path.read_text(encoding='utf-8'))
    expected = copy.deepcopy(proposed)
    expected['budget']['status'] = 'APPROVED'
    assert approved == expected
    auth = json.loads(auth_path.read_text(encoding='utf-8'))
    human = json.loads(human_path.read_text(encoding='utf-8'))
    assert human['approval_text'] == '批准'
    assert human['authorization_id'] == auth['authorization_id']
    assert human['request']['sha256'] == sha(Path(human['request']['path']))
    assert human['current_snapshot']['sha256'] == sha(Path(human['current_snapshot']['path']))
    assert human['approved_config']['sha256'] == sha(approved_path)
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(ROOT / 'n2-development/controller-password-r10'))
    from standalone_controller import build_config
    from exact_record_authorization import validate_authorization
    from n2_controller import canonical_sha256
    config = build_config(approved, auth)
    assert validate_authorization(config, auth)
    claim_name = hashlib.sha256(auth['authorization_id'].encode()).hexdigest() + '.json'
    claim_path = Path(approved['consumption_root']) / claim_name
    claim = json.loads(claim_path.read_text(encoding='utf-8'))
    for key in ('authorization_id', 'run_identity', 'package_sha256', 'controller_sha256', 'controller_bundle_sha256', 'budget_sha256'):
        assert claim[key] == auth[key]
    assert claim['budget_sha256'] == canonical_sha256(approved['budget'])
    matching_claims = []
    for path in Path(approved['consumption_root']).glob('*.json'):
        row = json.loads(path.read_text(encoding='utf-8'))
        if row.get('authorization_id') == auth['authorization_id']:
            matching_claims.append(str(path))
    assert matching_claims == [str(claim_path)]
    trace_path = Path(approved['evidence_root']) / 'controller-transcript.txt'
    trace = trace_path.read_text(encoding='utf-8')
    assert trace.count('CONTROLLER_BEGIN') == 1
    starts = re.findall(r'^COMMAND_BEGIN label=(\S+)', trace, re.MULTILINE)
    assert starts == ['preflight_identity_and_cpu_json', 'create_remote_roots']
    assert trace.count('FIRST_ERROR ') == 1
    first = next(line for line in trace.splitlines() if line.startswith('FIRST_ERROR '))
    assert first == 'FIRST_ERROR type=FileNotFoundError detail=[Errno 2] No such file no_retry=true reconnects=0'
    assert trace.rstrip().endswith(first)
    assert 'COMMAND_BEGIN label=submit_once_and_observe' not in trace
    assert 'N2_INVOCATION_ID=' not in trace and 'CONTROLLER_RESULT' not in trace
    transfers = re.findall(r'^TRANSFER_FILE path=(\S+) sha256=(\S+)', trace, re.MULTILINE)
    assert [row[0] for row in transfers] == ['LOCAL_ENGINEERING_BUDGET.json', 'n2_contracts.py']
    package = Path(approved['package_root'])
    assert all(sha(package / name) == digest for name, digest in transfers)
    prearchive_receipt_path = ROOT / 'n2-governance/R10_PREEXECUTION_LOCAL_ARCHIVE_RECEIPT_20261015.json'
    prearchive_receipt = json.loads(prearchive_receipt_path.read_text(encoding='utf-8'))
    prearchive_path = Path(prearchive_receipt['archive_path'])
    assert sha(prearchive_path) == prearchive_receipt['archive_sha256']
    with zipfile.ZipFile(prearchive_path) as stream:
        assert stream.testzip() is None
        assert set(stream.namelist()) == {entry['archive_path'] for entry in prearchive_receipt['entries']}
        for entry in prearchive_receipt['entries']:
            assert hashlib.sha256(stream.read(entry['archive_path'])).hexdigest().upper() == entry['sha256'] == sha(Path(entry['source_path']))
    failure_archive = ROOT / 'archives/n2-r10-first-error-before-repair-20261015.zip'
    assert sha(failure_archive) == 'E6D858DA71A5D244E2433984FE119A725FA8A84BC34428162A5B38C692B20C18'
    with zipfile.ZipFile(failure_archive) as stream:
        assert stream.testzip() is None
        archived_traces = [name for name in stream.namelist() if name.endswith('controller-transcript.txt')]
        assert len(archived_traces) == 1
        assert hashlib.sha256(stream.read(archived_traces[0])).hexdigest().upper() == sha(trace_path)
        failed_archive_members = stream.namelist()
    optional_evidence = {}
    for argument in sys.argv[1:]:
        path = Path(argument)
        optional_evidence[str(path)] = {'sha256': sha(path), 'receipt': json.loads(path.read_text(encoding='utf-8'))}
    forensic_path = PREP / 'r10-failure-remote-readonly-20261015.json'
    terminal_path = PREP / 'r10-controller-terminal-observation-20261015.json'
    forensic = optional_evidence[str(forensic_path)]['receipt']
    terminal = optional_evidence[str(terminal_path)]['receipt']
    assert forensic['status'] == 'READ_ONLY_FORENSICS_COMPLETE'
    assert [item['path'] for item in forensic['inventory']] == ['package', 'package/LOCAL_ENGINEERING_BUDGET.json', 'package/n2_contracts.py', 'work']
    assert all(item['sha256'] == sha(package / item['path'].split('/', 1)[1]) for item in forensic['inventory'] if item['kind'] == 'file')
    assert forensic['bytes_read'] == 11361
    assert all(forensic[key] is False for key in ('controller_retried', 'upload_or_remote_write', 'training_started_by_this_check', 'authorization_created_or_consumed_by_this_check', 'credential_persisted'))
    unit = dict(line.split('=', 1) for line in forensic['commands'][0]['stdout'].splitlines())
    assert unit['LoadState'] == 'not-found' and unit['ActiveState'] == 'inactive' and unit['SubState'] == 'dead'
    assert unit['InvocationID'] == unit['ControlGroup'] == ''
    assert terminal['controller_launch_count'] == 1 and terminal['controller_exit_code'] == 1
    assert terminal['terminal_final_output'] == 'CONTROLLER_FAILED:FileNotFoundError'
    assert terminal['systemd_submission_attempted'] is False and terminal['automatic_retry'] is False
    result = {
        'schema': 'n2-independent-r10-actual-first-error-review/1',
        'status': 'ENGINEERING_STOPPED_PRE_SUBMISSION_NO_HOSTED_PASS',
        'approved_config_budget_status_only_change': True,
        'genuine_approval_and_exact_authorization_bindings_passed': True,
        'exact_authorization_validator_passed_without_run_or_consume': True,
        'one_matching_durable_consumption_claim': matching_claims,
        'authorization_consumed_must_not_reuse': True,
        'first_error': first,
        'command_order': starts,
        'logged_successful_transfers': [dict(path=name, sha256=digest) for name, digest in transfers],
        'systemd_submission_observed': False,
        'ledger_pending_calls': None,
        'ledger_status': 'NOT_STARTED_NOT_APPLICABLE',
        'wm_ppo_updates': None,
        'training_status': 'NOT_STARTED',
        'cgroup_settlement': 'NOT_APPLICABLE_NO_MANAGED_UNIT_STARTED',
        'verified_training_export': 'NOT_CREATED',
        'remote_partial_upload_exists': True,
        'readonly_remote_files_match_logged_transfers_and_work_empty': True,
        'unit_not_found_no_invocation_or_controlgroup': True,
        'terminal_exit_code': 1,
        'terminal_exit_provenance': 'Root saved local tool observation, not an independent remote runtime receipt',
        'failure_archive_sha256': sha(failure_archive),
        'failure_archive_members': failed_archive_members,
        'preexecution_archive_sha256': sha(prearchive_path),
        'source_hashes': {str(path.relative_to(ROOT)): sha(path) for path in (approved_path, proposed_path, auth_path, human_path, claim_path, trace_path, prearchive_receipt_path)},
        'additional_termination_or_readonly_evidence': optional_evidence,
        'reviewer_ssh_experiment_implementation_or_authorization_creation': False,
    }
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in result.items() if key not in ('source_hashes', 'additional_termination_or_readonly_evidence', 'failure_archive_members')}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
