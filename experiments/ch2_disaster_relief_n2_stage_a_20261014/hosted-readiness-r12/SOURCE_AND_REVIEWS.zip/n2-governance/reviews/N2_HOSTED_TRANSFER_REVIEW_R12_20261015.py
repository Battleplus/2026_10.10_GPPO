"""Independent local audit. No SSH, controller run, or approval manufacture."""
import errno
import hashlib
import json
import posixpath
import stat
import sys
from pathlib import Path
from types import SimpleNamespace

ROOT = Path('E:/10.14')
SOURCE = ROOT / 'n2-development/controller-transfer-r12'
SNAPSHOT = ROOT / 'n2-development/controller-transfer-r12-SNAPSHOT_SHA256.json'
PROPOSAL = ROOT / 'n2-development/hosted-preparation-evidence/controller-config-proposed-r12-transfer-20261015.json'
REMOTE = '/home/user1/independent-mock/package'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()).hexdigest().upper()


class MemorySftp:
    """Directory-exact fake: no automatic parents, stat following, or overwrite."""
    def __init__(self, clock):
        self.clock = clock
        self.nodes = {'/': (stat.S_IFDIR, None)}
        current = ''
        for part in REMOTE.strip('/').split('/'):
            current += '/' + part
            self.nodes[current] = (stat.S_IFDIR, None)
        self.events = []
        self.closed = False
        self.timeout = None
        self.advance = None
        self.deny = None
        self.mkdir_race = None

    def get_channel(self):
        return self

    def settimeout(self, value):
        assert 0 < value <= 1000
        self.timeout = value
        self.events.append(('timeout', value))

    def event(self, method, path):
        assert self.events and self.events[-1][0] == 'timeout'
        assert abs(self.timeout - (1000 - self.clock[0])) < 1e-8
        self.events.append((method, path))
        self.clock[0] += 0.01
        if self.advance == (method, path):
            self.clock[0] = 1001

    def lstat(self, path):
        self.event('lstat', path)
        if self.deny == ('lstat', path):
            raise PermissionError(errno.EACCES, 'denied', path)
        if path not in self.nodes:
            raise FileNotFoundError(errno.ENOENT, 'missing', path)
        return SimpleNamespace(st_mode=self.nodes[path][0] | 0o700)

    def stat(self, path):
        raise AssertionError('stat follows symlinks and is forbidden in this probe')

    def mkdir(self, path, mode=0o700):
        self.event('mkdir', path)
        assert mode == 0o700
        if self.deny == ('mkdir', path):
            raise PermissionError(errno.EACCES, 'denied', path)
        assert self.nodes.get(posixpath.dirname(path), (None,))[0] == stat.S_IFDIR
        if self.mkdir_race == path:
            self.nodes[path] = (stat.S_IFDIR, None)
            raise FileExistsError(errno.EEXIST, 'racing directory', path)
        if path in self.nodes:
            raise FileExistsError(errno.EEXIST, 'exists', path)
        self.nodes[path] = (stat.S_IFDIR, None)

    def put(self, local, remote, confirm=True):
        self.event('put', remote)
        assert confirm is True
        assert self.nodes.get(posixpath.dirname(remote), (None,))[0] == stat.S_IFDIR
        assert remote not in self.nodes, 'overwrite reached fake server'
        self.nodes[remote] = (stat.S_IFREG, Path(local).read_bytes())

    def close(self):
        self.closed = True
        self.events.append(('close',))


class Client:
    def __init__(self, sftp):
        self.sftp = sftp
        self.opened = False

    def open_sftp(self):
        self.opened = True
        return self.sftp


class Evidence:
    def __init__(self):
        self.rows = []

    def write(self, value):
        self.rows.append(value)


def main():
    sys.dont_write_bytecode = True
    snapshot = json.loads(SNAPSHOT.read_text(encoding='utf-8'))
    observed = {p.relative_to(SOURCE).as_posix(): sha(p) for p in SOURCE.rglob('*') if p.is_file()}
    assert observed == snapshot['file_sha256']
    assert canonical(observed) == snapshot['source_tree_sha256']
    assert sha(PROPOSAL) == snapshot['proposal']['sha256']
    test_log = Path(snapshot['test']['log_path'])
    assert sha(test_log) == snapshot['test']['log_sha256']
    assert snapshot['test']['tests_run'] == 36
    assert 'Ran 36 tests' in test_log.read_text(encoding='utf-8')
    assert test_log.read_text(encoding='utf-8').rstrip().endswith('OK')
    raw = json.loads(PROPOSAL.read_text(encoding='utf-8'))
    assert raw['budget']['status'] == 'NOT_APPROVED'
    old_raw = json.loads((ROOT / 'n2-development/hosted-preparation-evidence/controller-config-proposed-r11-transfer-20261015.json').read_text(encoding='utf-8'))
    changed_config = sorted(k for k in raw if raw[k] != old_raw[k])
    assert changed_config == ['consumption_root']
    assert raw['consumption_root'].endswith('authorization-consumption-r12')
    assert raw['ssh_auth_mode'] == 'password' and raw['ssh_key_file'] is None
    old_source = ROOT / 'n2-development/controller-password-r10'
    changes = sorted(k for k, v in observed.items() if sha(old_source / k) != v)
    assert changes == ['n2_controller.py', 'test_n2_controller.py']
    sys.path.insert(0, str(SOURCE))
    import n2_controller as controller
    import standalone_controller
    import exact_record_authorization
    assert controller.controller_bundle_sha256() == snapshot['controller_bundle_sha256']
    assert exact_record_authorization.standalone_source_sha256() == snapshot['standalone_source_sha256']
    config = standalone_controller.build_config(raw, {})
    try:
        exact_record_authorization.validate_authorization(config, {})
    except ValueError as exc:
        assert str(exc) == 'BUDGET_NOT_APPROVED'
    else:
        raise AssertionError('unapproved proposal admitted')
    old_approved = json.loads((ROOT / 'n2-development/hosted-preparation-evidence/controller-config-approved-r10-password-20261015.json').read_text(encoding='utf-8'))
    try:
        controller.validate_local(standalone_controller.build_config(old_approved, {}))
    except ValueError as exc:
        assert str(exc) == 'CONSUMED_RUN_IDENTITY_FORBIDDEN'
    else:
        raise AssertionError('consumed R10 identity admitted')
    package = Path(raw['package_root'])
    manifest_path = package / raw['manifest_rel']
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    assert sha(manifest_path) == raw['package_sha256']
    assert len(manifest['files']) == 54
    assert {r: sha(package / r) for r in manifest['files']} == manifest['file_sha256']
    content = ''.join(r + '=' + manifest['file_sha256'][r] + '\n' for r in sorted(manifest['files']))
    assert hashlib.sha256(content.encode()).hexdigest().upper() == manifest['package_content_sha256']
    rows = [(r, package / r, sha(package / r)) for r in sorted(manifest['files'])]
    rows += [('manifest.json', manifest_path, sha(manifest_path))]
    rows += [('managed-controller/' + r, p, h) for r, p, h in controller.controller_bundle_rows()]
    assert len(rows) == 64

    def execute(selected, setup=None, expected=None, start=0):
        clock = [float(start)]
        sftp = MemorySftp(clock)
        if setup:
            setup(sftp)
        evidence = Evidence()
        client = Client(sftp)
        try:
            controller._transfer(selected, client, evidence, REMOTE, 1000.0, lambda: clock[0])
        except BaseException as exc:
            if expected is None or not isinstance(exc, expected):
                raise
        else:
            assert expected is None, 'expected failure was admitted'
        assert sftp.closed or not client.opened
        return sftp, evidence

    full, ev = execute(rows)
    actual = {p[len(REMOTE) + 1:]: hashlib.sha256(data).hexdigest().upper()
              for p, (kind, data) in full.nodes.items() if kind == stat.S_IFREG}
    assert actual == {r: h for r, p, h in rows}
    assert len(ev.rows) == 64
    assert REMOTE + '/references/civil' in full.nodes
    assert REMOTE + '/managed-controller/vendor' in full.nodes
    nested = next(row for row in rows if row[0] == 'references/civil/__init__.py')
    cases = []
    def failure(name, selected, setup, error, start=0):
        fake, evidence = execute(selected, setup, error, start)
        assert not any(e[0] == 'put' for e in fake.events)
        assert not evidence.rows
        cases.append(name)

    for path in ('/home', '/home/user1', '/home/user1/independent-mock', REMOTE, REMOTE + '/references'):
        for kind in (stat.S_IFLNK, stat.S_IFREG):
            failure('parent-kind-' + str(kind) + '-' + path, [nested],
                    lambda f, p=path, k=kind: f.nodes.__setitem__(p, (k, b'existing')), NotADirectoryError)
    for kind in (stat.S_IFLNK, stat.S_IFREG, stat.S_IFDIR):
        failure('destination-kind-' + str(kind), [rows[0]],
                lambda f, k=kind: f.nodes.__setitem__(REMOTE + '/' + rows[0][0], (k, b'existing')), FileExistsError)
    for relative in ('../x', 'a/../../x', '/x', 'a//x', './x', 'a/./x', 'a\\x', '', 'x\x00z'):
        failure('relative-' + repr(relative), [(relative, rows[0][1], rows[0][2])], None, ValueError)
    failure('permission-mkdir', [nested], lambda f: setattr(f, 'deny', ('mkdir', REMOTE + '/references')), PermissionError)
    failure('permission-lstat', [nested], lambda f: setattr(f, 'deny', ('lstat', REMOTE + '/references')), PermissionError)
    failure('expired-before-open', [nested], None, TimeoutError, start=1000)
    failure('expiry-during-mkdir', [nested], lambda f: setattr(f, 'advance', ('mkdir', REMOTE + '/references')), TimeoutError)
    failure('expiry-during-missing-destination', [rows[0]], lambda f: setattr(f, 'advance', ('lstat', REMOTE + '/' + rows[0][0])), TimeoutError)
    late, late_ev = execute([rows[0]], lambda f: setattr(f, 'advance', ('put', REMOTE + '/' + rows[0][0])), TimeoutError)
    assert not late_ev.rows
    cases.append('final-put-late-return-detected-no-success-log')
    race, race_ev = execute([nested], lambda f: setattr(f, 'mkdir_race', REMOTE + '/references'))
    assert len(race_ev.rows) == 1
    cases.append('existing-directory-race-confirmed')

    delegation_path = ROOT / 'n2-development/hosted-preparation-evidence/cgroup-delegation-readonly-20261015.json'
    delegation = json.loads(delegation_path.read_text(encoding='utf-8'))
    commands = {item['label']: item for item in delegation['commands']}
    layout = json.loads(commands['controller_delegation_layout']['stdout'])
    by_path = {item['path']: item for item in layout['rows']}
    service = '/sys/fs/cgroup/user.slice/user-1000.slice/user@1000.service'
    assert by_path[service]['cgroup.controllers'].split() == ['memory', 'pids']
    assert 'cpu.max' not in by_path[service] and 'cpuset.cpus.effective' not in by_path[service]
    assert 'DelegateControllers=memory pids\n' in commands['system_user_manager_properties']['stdout']
    assert all(delegation[k] is False for k in ('remote_upload_or_write', 'unit_created', 'training_started', 'controller_retry', 'authorization_created_or_consumed', 'credential_persisted'))
    preflight_path = ROOT / 'n2-development/hosted-preparation-evidence/ssh-runtime-preflight-r12-20261015.json'
    preflight = json.loads(preflight_path.read_text(encoding='utf-8'))
    assert preflight['status'] == 'READ_ONLY_PREFLIGHT_MATCH' and preflight['runtime_mismatches'] == {}
    assert preflight['controller_sha256'] == sha(SOURCE / 'n2_controller.py')
    assert preflight['standalone_sha256'] == sha(SOURCE / 'standalone_controller.py')
    assert preflight['config_sha256'] == sha(PROPOSAL)
    assert all(preflight[key] is False for key in ('remote_upload', 'remote_training', 'authorization_consumed', 'credential_persisted'))
    assert all(command['exit_code'] == 0 for command in preflight['commands'])

    result = {
        'schema': 'n2-independent-r12-transfer-review/1',
        'status': 'PASS_LOCAL_NARROW_TRANSFER_REVIEW_HOSTED_READINESS_SEPARATE',
        'snapshot_record_sha256': sha(SNAPSHOT),
        'source_tree_sha256': canonical(observed),
        'source_file_sha256': observed,
        'controller_sha256': sha(SOURCE / 'n2_controller.py'),
        'controller_bundle_sha256': controller.controller_bundle_sha256(),
        'standalone_source_sha256': exact_record_authorization.standalone_source_sha256(),
        'proposal_sha256': sha(PROPOSAL),
        'executor_test_log_sha256': sha(test_log),
        'executor_test_count': 36,
        'cgroup_delegation_receipt_sha256': sha(delegation_path),
        'exact_readonly_preflight_receipt_sha256': sha(preflight_path),
        'hosted_readiness': 'NOT_READY_CPU_CPUSET_DELEGATION_MISSING',
        'package_manifest_sha256': sha(manifest_path),
        'package_content_sha256': manifest['package_content_sha256'],
        'source_changes_from_r10': changes,
        'proposal_changes_from_r11': changed_config,
        'full_real_payload_plus_manifest_plus_bundle_rows': len(rows),
        'strict_mock_transferred_all_hashes': True,
        'cases': cases,
        'unapproved_proposal_rejected': True,
        'consumed_r10_identity_rejected': True,
        'reviewer_ssh_training_or_controller_run': False,
        'authorization_created_or_consumed': False,
        'hosted_transfer_acceptance': 'NOT_RUN',
    }
    target = Path(__file__).with_suffix('.json')
    assert not target.exists(), 'preserve earlier audit result'
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'source_file_sha256'}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
