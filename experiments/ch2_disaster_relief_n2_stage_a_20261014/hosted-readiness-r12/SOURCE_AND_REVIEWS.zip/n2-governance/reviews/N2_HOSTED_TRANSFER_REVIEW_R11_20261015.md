# R11 independent transfer review — correction required

Reviewed locally on 2026-10-15. No SSH, upload, hosted execution, experiment, authorization creation, or authorization consumption was performed by this reviewer.

The R11 recursive-directory fix addresses R10's missing intermediate parent failure, but R11 is not accepted for a hosted attempt. Its source tree is `317F2340BE337323E9B57F799C0876C5D47FF8560E0E80EBC4ECBCCA37D177F0`; `n2_controller.py` is `5477C5253ACDD8CAE7218A45DEFA8701443362A22DE89183494DC9E7F2437AAD`. The proposed configuration remains NOT_APPROVED (SHA-256 `4AB96FBB180FF887216AAF49C7255540CCCE574BE0513645E2B5CD40D803FA6D`).

1. `n2_controller.py:534-562` checks remote package root and parents with `sftp.stat`, which follows symbolic links. A link to a directory satisfies the checks, so lexical confinement does not establish filesystem confinement. `_transfer` also calls `put` without refusing existing destination files or links, allowing collision overwrite.
2. `n2_controller.py:569-583` sets one channel timeout and checks the deadline only before each file. Directory operations may exhaust the remaining deadline, yet `put` can still begin afterward. The timeout is not refreshed to the remaining budget before each operation.

These are source-inspection findings; no real transfer acceptance is claimed. The existing 32-test passing log does not cover these boundary cases. Both findings were reported to the parent and executor before implementation correction. The parent preserved R11 in `E:/10.14/archives/n2-r11-unapproved-before-boundary-repair-20261015.zip`, SHA-256 `64FA34D6FD4B5BBF83DB9AB647C2C81C0D7CD14CA93FA5499D8FAE24B2893608`.

R12 will receive a separate independent review. R10's consumed authorization remains unusable. Any actual hosted attempt requires fresh exact human approval; this review provides no authorization. Stage A remains incomplete, and the formal research budget remains UNFROZEN.
