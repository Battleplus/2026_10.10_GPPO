# Independent actual R10 first-error review

Reviewer: GPT-6.1 Sol, high reasoning. Date: 2026-10-15.

Verdict: **ENGINEERING STOPPED BEFORE SYSTEMD SUBMISSION. No hosted acceptance PASS.** The sole approved R10 attempt consumed its authorization and terminated on a real SFTP transfer error. The reviewed evidence supports first-error termination without a controller retry. Stage A remains incomplete.

## Approval and consumption

The approved config differs from the preserved proposed config only in `budget.status`, from NOT_APPROVED to APPROVED. Approved-config SHA-256 is `1B81D8750FB6BEADF70AE6085F80392DFB8D0FEE564430753429C3BEDFB5529D`. The human approval receipt records the current-chat reply `批准` for one exact Stage A engineering attempt and explicitly labels its timestamp as observation time. It binds the unchanged request, current B6D snapshot metadata and independent metadata addendum. It authorizes no formal B/C/D work.

The exact authorization validator independently passes for the genuine approved config and record; the reviewer did not manufacture an approved record or call the run/consume functions. Authorization ID:

`n2-r10-stage-a-engineering-once-20261015-086e7eeae47d4006920f8c5f94b851f6`

Exactly one matching persistent consumption record exists at `E:/10.14/n2-governance/authorization-consumption/4a762cdf85e9793298c8ab9587b7c983acec948ebb31cfe987fb706b33d93eab.json`. Its authorization/run/package/controller/bundle/budget values match the exact approved record. Its SHA-256 is `6C5EF85E436D8C1A0EF40710C459EE267F0E60C6F7D3E0220C772821BDBAE5AF`. **This authorization and run identity must not be reused.**

The approved artifacts were separately archived before execution in `E:/10.14/archives/n2-r10-approved-pre-execution-20261015.zip`, SHA-256 `E28B6A3177DB1B077C08630ED84124D274D3301E097B52891DC38FD02ACCE5C6`. The independent audit verifies CRC, inventory and all nine member/source hashes against its receipt.

## Actual sequence and first error

The transcript at `E:/10.14/n2-development/runs/n2-managed-engineering-r1-20261014-once/controller-transcript.txt` contains one controller start, then:

1. `preflight_identity_and_cpu_json`, exit 0: exact target identity, fresh root absence and cpuset/affinity admission passed.
2. `create_remote_roots`, exit 0: package/work directories created.
3. Two successful transfer records: `LOCAL_ENGINEERING_BUDGET.json` and `n2_contracts.py`, with their frozen hashes.
4. One terminal first-error record: `FileNotFoundError: [Errno 2] No such file`, `no_retry=true reconnects=0`.

There is no transferred-package verification command, `submit_once_and_observe` command, InvocationID or controller success receipt. The transcript ends at the first error. The saved local terminal observation records one launch, exit 1 and `CONTROLLER_FAILED:FileNotFoundError`; it is explicitly a root observation of the terminal tool, not an independent remote runtime receipt.

The source explains the transfer failure: `_transfer` attempts `sftp.mkdir` only for a file's immediate parent. The sorted third payload is `references/civil/__init__.py`; its parent requires the absent intermediate `references` directory. After mkdir fails, the fallback stat also fails. The evidence identifies this mechanism without claiming an unrecorded server-side traceback. This defect escaped the prior mocked source-readiness coverage; the earlier narrow review was not a live transfer acceptance.

## Independent read-only remote confirmation

The separately collected `r10-failure-remote-readonly-20261015.json` reports exactly the two transferred files, 2,339 and 9,022 bytes, and hashes matching the frozen payload. Work is empty and there is no references directory. The check read 11,361 file bytes and records no remote write, controller retry, training or authorization creation/consumption by the check.

Its unit readback is LoadState=not-found, ActiveState=inactive, SubState=dead, with empty InvocationID and ControlGroup. The accompanying default `Result=success` and `ExecMainStatus=0` do **not** demonstrate a successful managed run: no unit was loaded or invoked. The forensic connection is separate from the failed controller connection and is not a retry of the engineering attempt.

Because failure preceded submission, StageServer and BudgetLedger were not started. Pending calls, WM/PPO updates and managed cgroup settlement are **not applicable / not started**, represented as null where numeric fields would otherwise imply a measured zero. No verified training-evidence ZIP was created. There is no post-submission unit to stop or settle; partial uploaded source remains evidence and is not a completed worker export.

## Preserved evidence and next boundary

The first-error archive was preserved before repair: `E:/10.14/archives/n2-r10-first-error-before-repair-20261015.zip`, SHA-256 `E6D858DA71A5D244E2433984FE119A725FA8A84BC34428162A5B38C692B20C18`. Its CRC and archived transcript digest match the current evidence.

| Evidence | SHA-256 |
|---|---|
| Actual transcript | `E1C1E0DC8FC7432D9656633145091D7CA061AA78CA5368DED7763F3CB2B97700` |
| Separate read-only remote forensic receipt | `20ACE35313B1964BB37996057863C1784EA76A8A5DC7B8107643D383CD964597` |
| Local terminal observation | `5B0EE36AADAF836E2820DF445BF5DC99B6424F88B924AF7172B21E6A3B102AC3` |

The same-prefix independent `.py` and `.json` files preserve exact checks and source/evidence hashes. The first local audit invocation exposed a Windows default-decoding mismatch on the Chinese approval text; the reviewer corrected only the new audit script to use explicit UTF-8 and reran its read-only checks successfully. No controller implementation, remote state, password, authorization or experiment was modified by the reviewer.

A future isolated recursive-directory transfer repair requires its own concrete review and fresh run/unit/root/authorization before another actual attempt. This report does not authorize that attempt. First-error preservation succeeded; live hosted systemd/StageServer/BudgetLedger acceptance, complete resource settlement, verified raw export and research-budget readiness remain outstanding.
