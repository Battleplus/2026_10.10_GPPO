# Independent review: runtime CPU/cpuset delegation proposal

**Review scope:** `n2-development/hosted-preparation-evidence/admin-delegation-proposal-20261015.md`

**Review status:** PASS AS A CONDITIONAL ADMINISTRATIVE PREREQUISITE; NOT EXECUTED.

The proposal is appropriately narrow. The installed systemd 249 documentation supports an explicit `Delegate=` controller list, and the proposed runtime property retains `memory pids` while adding `cpu cpuset`. It does not widen the R12 operation caps, alter quotas, change affinity, restart the user manager, create a unit, upload files, or start training.

The command is valid only after a fresh approval from an identified administrator. Membership in `sudo` and a password prompt do not establish that approval. The operation must use the existing strict known-hosts check and interactive SSH/sudo prompts without persisting credentials.

Before mutation, the administrator must verify the live UID 1000 manager, its exact current `DelegateControllers=memory pids`, active state, cgroup-v2 mount and paths, and no concurrent administrator change. After the single runtime property update, the same properties and cgroup files must be captured. A successful `systemctl set-property` exit code alone is insufficient: the execution hierarchy must expose the required controllers, have a non-empty effective cpuset, and have the finite `cpu.max` required by the unchanged service contract. Memory and pids must remain available and unrelated settings must be unchanged.

The proposal correctly states that delegation applies to the whole `user@1000.service` manager and may affect ancestor controller propagation and existing UID 1000 workloads. It is not limited to a future N2 unit. The runtime rollback to `Delegate=memory pids` is useful but is not a full rollback of ancestor controller state or all runtime drop-in effects; the proposal records that limitation.

**Decision:** retain the target as `HOSTED_NOT_READY` until the administrator performs the separately approved change and a fresh read-only verification passes. Do not create a new R12 authorization or consume the existing R10 authorization while this prerequisite is unresolved.

This review was supplied by the independent GPT-6.1 Sol reviewer in the task review channel after inspecting the proposal and the read-only delegation receipts. No SSH mutation or controller execution was performed by the reviewer.
