"""Independent auth/cpuset audit only; never connects or makes authorization."""
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path('E:/10.14')
CONTROLLER = ROOT / 'n2-development/controller-password-r10'
SNAPSHOT = ROOT / 'n2-development/controller-password-r10-SNAPSHOT_SHA256.json'
RECEIPT = ROOT / 'n2-development/hosted-preparation-evidence/ssh-runtime-preflight-r10-20261015.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def canonical(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()).hexdigest().upper()


def main():
    snapshot = json.loads(SNAPSHOT.read_text(encoding='utf-8'))
    observed = {path.relative_to(CONTROLLER).as_posix(): sha(path) for path in CONTROLLER.rglob('*') if path.is_file()}
    assert observed == snapshot['file_sha256']
    assert canonical(observed) == snapshot['canonical_sha256_excluding_this_file']
    config_path = Path(snapshot['proposed_config']['path'])
    assert sha(config_path) == snapshot['proposed_config']['sha256']
    raw = json.loads(config_path.read_text(encoding='utf-8'))
    assert raw['ssh_auth_mode'] == 'password' and raw['ssh_key_file'] is None
    assert raw['budget']['status'] == 'NOT_APPROVED'
    assert not any(key in raw for key in ('password', 'ssh_password', 'credential'))
    receipt = json.loads(RECEIPT.read_text(encoding='utf-8'))
    assert receipt['status'] == 'READ_ONLY_PREFLIGHT_MATCH' and receipt['runtime_mismatches'] == {}
    assert receipt['controller_sha256'] == snapshot['controller_sha256']
    assert receipt['standalone_sha256'] == observed['standalone_controller.py']
    assert receipt['config_sha256'] == sha(config_path)
    assert all(receipt[key] is False for key in ('remote_upload', 'remote_training', 'authorization_consumed', 'credential_persisted'))
    assert sha(Path(snapshot['verification']['log_path'])) == snapshot['verification']['log_sha256']
    assert snapshot['verification']['tests'] == 28
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(CONTROLLER))
    import n2_controller
    import standalone_controller
    import exact_record_authorization
    config = standalone_controller.build_config(raw, {})
    assert n2_controller.controller_bundle_sha256() == snapshot['controller_bundle_sha256']
    assert exact_record_authorization.standalone_source_sha256() == snapshot['standalone_source_sha256']
    # The concrete proposed config must reject without any manufactured approval.
    try:
        exact_record_authorization.validate_authorization(config, {})
    except ValueError as exc:
        assert str(exc) == 'BUDGET_NOT_APPROVED'
    else:
        raise AssertionError('proposed budget accepted')
    with patch('standalone_controller.sys.stdin.isatty', return_value=False), patch('standalone_controller.getpass.getpass') as prompt:
        try:
            standalone_controller._password_from_tty()
        except RuntimeError as exc:
            assert str(exc) == 'SSH_PASSWORD_TTY_REQUIRED'
        else:
            raise AssertionError('non-TTY password allowed')
        prompt.assert_not_called()
    wrong = {**raw, 'ssh_key_file': 'forbidden-key-reference'}
    try:
        standalone_controller.build_config(wrong, {})
    except ValueError as exc:
        assert str(exc) == 'CONTROLLER_PASSWORD_KEYFILE_FORBIDDEN'
    else:
        raise AssertionError('password/key mixture allowed')
    first = next(item for item in receipt['commands'] if item['label'] == 'exact_fresh_identity_and_cpu')
    affinity, allowed = n2_controller.parse_affinity_json(first['stdout'])
    assert affinity == allowed == list(range(32))
    cpu_record = json.loads(first['stdout'].strip().split('=', 1)[1])
    assert cpu_record['cpuset_source'] == '/sys/fs/cgroup/user.slice'
    helper = {}
    exec(n2_controller.REMOTE_CPUSET_HELPER_SOURCE, helper)
    with tempfile.TemporaryDirectory(prefix='r10-independent-cpuset-') as temporary:
        root = Path(temporary)
        cgroup = root / 'cgroup'
        cgroup.write_text('0::/user.slice/user-1000.slice/session-258.scope\n')
        mount = root / 'mountinfo'
        mount.write_text('30 1 0:27 / /sys/fs/cgroup rw - cgroup2 cgroup rw\n')
        tree = root / 'tree'
        (tree / 'user.slice/user-1000.slice/session-258.scope').mkdir(parents=True)
        (tree / 'cpuset.cpus.effective').write_text('0-63\n')
        (tree / 'user.slice/cpuset.cpus.effective').write_text('0-31\n')
        cpus, source = helper['_resolve_effective_cpuset'](cgroup, mount, tree)
        assert cpus == list(range(32)) and Path(source) == tree / 'user.slice'
        (tree / 'user.slice/cpuset.cpus.effective').unlink()
        (tree / 'cpuset.cpus.effective').unlink()
        try:
            helper['_resolve_effective_cpuset'](cgroup, mount, tree)
        except ValueError as exc:
            assert str(exc) == 'CGROUP2_CPUSET_EFFECTIVE_UNAVAILABLE'
        else:
            raise AssertionError('missing cpuset silently accepted')
    r9 = ROOT / 'n2-development/controller-final-r9'
    r9_snapshot = json.loads((ROOT / 'n2-development/controller-final-r9-SNAPSHOT_SHA256.json').read_text())
    r9_observed = {path.relative_to(r9).as_posix(): sha(path) for path in r9.rglob('*') if path.is_file()}
    assert r9_observed == r9_snapshot['file_sha256']
    assert canonical(r9_observed) == snapshot['source_lineage']['r9_canonical_sha256']
    assert sha(Path(raw['package_root']) / raw['manifest_rel']) == raw['package_sha256'] == snapshot['source_lineage']['hosted_package_manifest_sha256']
    result = {
        'schema': 'n2-independent-r10-auth-cpuset-review/1',
        'status': 'PASS_NARROW_REVIEW_NOT_RUN_AUTHORIZATION',
        'controller_snapshot_sha256': canonical(observed),
        'controller_sha256': snapshot['controller_sha256'],
        'controller_bundle_sha256': snapshot['controller_bundle_sha256'],
        'standalone_source_sha256': snapshot['standalone_source_sha256'],
        'config_sha256': sha(config_path),
        'exact_preflight_receipt_sha256': sha(RECEIPT),
        'snapshot_record_sha256': sha(SNAPSHOT),
        'source_sha256': observed,
        'source_snapshot_config_log_receipt_hash_bindings_match': True,
        'r9_immutable_snapshot_matches': True,
        'hosted_manifest_preserved': True,
        'proposed_budget_rejects_without_auth': True,
        'non_tty_refused_before_prompt': True,
        'password_keyfile_mixture_rejected': True,
        'actual_receipt_affinity_cpuset_admission_passed': True,
        'nearest_effective_ancestor_and_missing_value_probes_passed': True,
        'approval_created_or_consumed': False,
        'reviewer_ssh_training_or_experiment': False,
        'hosted_managed_acceptance': 'NOT_RUN',
    }
    target = Path(__file__).with_suffix('.json')
    target.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'source_sha256'}, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
