# Independent R10 password and cpuset review

Reviewer: GPT-6.1 Sol, high reasoning. Date: 2026-10-15.

Verdict: **PASS for the narrow R10 password-authentication and observed cgroup-preflight fixes.** The final source and concrete proposed configuration are suitable for requesting fresh exact approval for one bounded managed engineering attempt. This report grants no execution authorization. Managed hosted acceptance remains **NOT RUN** and Stage A remains incomplete.

## Exact reviewed identities

| Artifact | SHA-256 |
|---|---|
| R10 canonical 17-file source snapshot | `C7A451A43B693690AA2D4B6F59FD74930888B15304410C95C4482752589DB60E` |
| R10 `n2_controller.py` | `B8EEF6E80ED2130073DF316CF4C25169F443B2C3D1F8956AFB110C52B1F6D6BF` |
| Managed controller bundle | `10DA0133BD5511596AB3EFFF7BC9A053FE1B6872FA12F502BC9FB0CAF6CF71D1` |
| Standalone entry and authorization source mapping | `7572EC9F3ADADA4E403C44CF9AAA7B8A693030A1DAA941A8B97614F89221D252` |
| Proposed password-mode configuration | `9C812ECFC8CF9DDF24A33380890E89A52F0A2174A3F7955EBC9A429295827FF3` |
| Exact R10 read-only preflight receipt | `DC9D3DAFA0E935FC7B94FF54774C9A1303BCCC71F2CD1BB826502A038ACEACA9` |
| Snapshot metadata record | `5215D07FA2A7AFF21AEDCDA088E014C0A4269EDFAB185FE344B332E5339DA07B` |
| Existing 28-test local mocked log | `3737A8CE1D6B279BDA34E01FEA51AEA9F602AEA9497EA77312B3CADBF846B1CD` |

The source directory is `E:/10.14/n2-development/controller-password-r10`. Metadata is `controller-password-r10-SNAPSHOT_SHA256.json` in its parent. The config and actual read-only receipt are `hosted-preparation-evidence/controller-config-proposed-r10-password-20261015.json` and `hosted-preparation-evidence/ssh-runtime-preflight-r10-20261015.json`.

All 17 source files and canonical/bundle/standalone mappings independently match the freeze; the test-log digest and config/receipt source bindings match. R9's canonical source mapping remains `6243B63A531EDD25E8F51D3A6BB05183EDD7195B59A92DC532B0D6636337531B`. The worker package manifest remains `661C80171B56DA0C45A072AA6699EE9D21032C2B3BB63D639286894D5655B05E`. This task did not repeat the scientific/package audit or modify earlier reports.

## Password and one-time authorization assessment

The concrete config explicitly selects `ssh_auth_mode: password` and requires `ssh_key_file: null`. Its allowed fields contain no password value or credential field. The connector reads a password only through getpass with interactive stdin/stderr TTY checks, refuses GetPassWarning echo fallback and empty input, and supplies the value to Paramiko in process memory. It has no password argument, environment-variable input or credential-file output. No password value was read or printed by the reviewer.

Paramiko loads the configured known-hosts file and uses RejectPolicy. Unknown or changed host keys do not silently gain trust. Both modes disable SSH agent use and automatic key search. Password mode rejects a key reference; private-key mode continues to use its explicit reference. The exact-authorization validator and controller local checks both require the approved `ssh_auth_mode`, so a private-key record cannot authorize the password configuration. The source and budget digests remain bound alongside identity, run/unit, target, worker and persistent consumption-root fields.

The standalone path validates the exact authorization and local package before starting. Its TTY gate runs before the controller creates the persistent authorization claim; the controller consumes one authorization before its sole connection attempt. Existing no-retry/no-reconnect, same-invocation stop and failure-settlement behavior is preserved. A post-claim prompt cancellation, login failure or preflight failure must therefore remain a consumed failed attempt, not a reason to reuse the record.

The proposed budget is still `NOT_APPROVED`. The independent check passed an empty authorization object only to confirm `BUDGET_NOT_APPROVED` rejection; it created no approved placeholder and did not call the controller, connector or consumption function. The observed successful read-only password preflight is separate from approval for upload, systemd submission or training.

## Observed cgroup fix

The preceding real defect was a missing `cpuset.cpus.effective` on the SSH session leaf and its immediate parent. R10 reads unified membership plus cgroup2 mountinfo, decodes mount fields, maps mount root/mountpoint and namespace-relative membership, requires one resolvable mounted membership, then walks only within that mount boundary to the nearest available effective cpuset. Missing or ambiguous resolution rejects; it does not replace cpuset evidence with scheduler affinity. Existing CPU-list validation and the nonempty affinity/cpuset intersection gate remain in use.

For the actual target, the exact frozen R10 `_remote_preflight` receipt reports source `/sys/fs/cgroup/user.slice`, effective cpuset 0–31 and scheduler affinity 0–31. The independent parser check obtains the same admitted intersection. A tiny local filesystem probe confirms this nearest-ancestor choice over a wider mount-root cpuset and confirms rejection when no effective value exists. The existing mocked suite also covers namespace-root mapping. These checks support the observed target layout; they do not claim all possible cgroup mounts have been exercised.

The source-bound read-only receipt has status `READ_ONLY_PREFLIGHT_MATCH` and no runtime mismatches. It records Linux, Python 3.11.16, Torch 2.7.0+cu128, NumPy 1.26.0, Torch thread/inter-op counts 1/1, CUDA unavailable/uninitialized, reachable user systemd manager and proposed unit `not-found`. It records no remote upload, training, credential persistence or authorization consumption. This demonstrates the exact connector/preflight prerequisite, not live managed-unit admission or settlement.

## Validation and remaining gate

The independent local script and machine output have this report's filename prefix with `.py` and `.json` extensions. One bounded execution checked hashes and bindings, NOT_APPROVED rejection, non-TTY rejection before password prompting, password/key mixture rejection, the actual receipt's CPU parser result and nearest-ancestor/missing-cpuset behavior. It made no SSH connection, invoked no password prompt, ran no Torch/training experiment and created or consumed no authorization. The executor's separately frozen 28-test mocked suite passed and includes password-mode binding, secure prompt refusal, private-key compatibility and the preserved R9 settled CPU/memory guards.

The remaining action is legitimate fresh exact one-time approval for the concrete R10 request and an approved engineering budget, followed by one bounded managed Linux run. Do not reuse either historical consumed failure authorization. The target run must still produce systemd Type=exec admission, live StageServer handshakes, actual worker BudgetLedger settlement, final cgroup CPU/memory evidence, nonempty verified raw evidence export and failure/pending records. R9's sampled-storage limitation remains: the supervisor's observed high-water mark is noncontinuous and excludes the receipt-write tail. The unchanged research-budget readiness gap also remains. Only the required live acceptance and wider readiness evidence can complete Stage A.
