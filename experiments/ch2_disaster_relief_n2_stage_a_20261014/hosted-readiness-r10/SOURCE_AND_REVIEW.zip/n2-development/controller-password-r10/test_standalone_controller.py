from __future__ import annotations

import hashlib
import json
import pathlib
import sys
import tempfile
import unittest
from types import SimpleNamespace
from unittest.mock import patch

from exact_record_authorization import expected_authorization
from standalone_controller import load_json_object, run_standalone
from vendor.stage_contract import STAGE_ORDER


class StandaloneControllerTests(unittest.TestCase):
    def _fixture(self, root: pathlib.Path):
        package = root / "package"
        package.mkdir()
        worker = package / "worker.py"
        worker.write_text("def managed_worker(runtime):\n    return {}\n", encoding="utf-8")
        worker_hash = hashlib.sha256(worker.read_bytes()).hexdigest().upper()
        budget = {
            "status": "APPROVED",
            "wall_seconds_total_including_settlement": 180,
            "settlement_reserve_seconds": 30,
            "systemd_runtime_max_seconds": 180,
            "cpu_quota_percent": 100,
            "cgroup_memory_max_bytes": 1073741824,
        }
        manifest = {
            "identity": "n2-standalone-test-r1",
            "files": ["worker.py"],
            "file_sha256": {"worker.py": worker_hash},
            "managed_runtime": {
                "resource_request": {
                    "stage_order": list(STAGE_ORDER),
                    "stages": {stage: {} for stage in STAGE_ORDER},
                    "totals": {},
                },
                "guard_limits": {
                    "wall_seconds_total_including_settlement": 180,
                    "settlement_reserve_seconds": 30,
                    "complete_process_cpu_seconds_total_including_descendants_and_settlement": 90,
                    "settlement_cpu_reserve_seconds": 10,
                    "cgroup_memory_max_bytes": 1073741824,
                    "memory_settlement_reserve_bytes": 1048576,
                    "combined_working_plus_export_peak_bytes_max": 10485760,
                    "cpu_quota_percent": 100,
                },
            },
        }
        manifest_path = package / "manifest.json"
        manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        manifest_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest().upper()
        key = root / "private-key-reference"
        known_hosts = root / "known-hosts-reference"
        key.write_text("private key reference only", encoding="utf-8")
        known_hosts.write_text("host key reference", encoding="utf-8")
        raw = {
            "package_root": str(package),
            "manifest_rel": "manifest.json",
            "package_sha256": manifest_hash,
            "expected_identity": manifest["identity"],
            "run_identity": "n2-standalone-test-once",
            "unit": "n2-standalone-test-once.service",
            "target_host": "approved-host",
            "target_user": "approved-user",
            "connect_host": "127.0.0.1",
            "remote_root": "/tmp/n2-standalone-test-once",
            "python": "/usr/bin/python3",
            "worker_entry": "worker.py",
            "worker_args": [],
            "ssh_auth_mode": "private_key",
            "ssh_key_file": str(key),
            "known_hosts": str(known_hosts),
            "evidence_root": str(root / "evidence"),
            "budget": budget,
            "consumption_root": str(root / "consumed"),
        }
        return raw

    def _write_pair(self, root: pathlib.Path, raw: dict[str, object]):
        config_path = root / "controller-config.json"
        authorization_path = root / "approved-authorization.json"
        provisional = {
            "approval_status": "APPROVED",
            "one_time_execution": True,
            "authorization_id": "test-auth-id",
            "approved_at": "2026-10-14T10:00:00+08:00",
            "approved_by": "test-coordinator",
        }
        from standalone_controller import build_config

        config = build_config(raw, provisional)
        authorization = {
            **expected_authorization(config),
            **provisional,
        }
        config_path.write_text(json.dumps(raw), encoding="utf-8")
        authorization_path.write_text(json.dumps(authorization), encoding="utf-8")
        return config_path, authorization_path, authorization

    def test_not_approved_template_rejects_before_connect_or_evidence(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            template = load_json_object(
                pathlib.Path(__file__).with_name("controller_config.template.json")
            )
            authorization = root / "authorization.json"
            authorization.write_text("{}", encoding="utf-8")
            calls = []
            with self.assertRaisesRegex(ValueError, "BUDGET_NOT_APPROVED"):
                run_standalone(
                    pathlib.Path(__file__).with_name("controller_config.template.json"),
                    authorization,
                    connect_factory=lambda **kwargs: calls.append(kwargs),
                )
            self.assertEqual(template["budget"]["status"], "NOT_APPROVED")
            self.assertEqual(calls, [])

    def test_exact_existing_authorization_reaches_only_the_mock_connector(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            config_path, authorization_path, _ = self._write_pair(root, self._fixture(root))
            calls = []

            class ConnectReached(RuntimeError):
                pass

            def connect(**kwargs):
                calls.append(kwargs)
                raise ConnectReached("mocked connector reached")

            with self.assertRaisesRegex(ConnectReached, "mocked connector reached"):
                run_standalone(config_path, authorization_path, connect_factory=connect)
            self.assertEqual(len(calls), 1)
            self.assertEqual(calls[0]["hostname"], "127.0.0.1")
            self.assertTrue((root / "consumed").is_dir())
            self.assertTrue((root / "evidence").is_dir())

    def test_authorization_mismatch_rejects_before_claim_or_connector(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            config_path, authorization_path, authorization = self._write_pair(root, self._fixture(root))
            authorization["worker_entry"] = "other.py"
            authorization_path.write_text(json.dumps(authorization), encoding="utf-8")
            calls = []
            with self.assertRaisesRegex(ValueError, "AUTHORIZATION_MISMATCH:worker_entry"):
                run_standalone(config_path, authorization_path, connect_factory=lambda **kwargs: calls.append(kwargs))
            self.assertEqual(calls, [])
            self.assertFalse((root / "consumed").exists())
            self.assertFalse((root / "evidence").exists())

    def test_duplicate_json_keys_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = pathlib.Path(temp) / "duplicate.json"
            path.write_text('{"status":"APPROVED","status":"NOT_APPROVED"}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "JSON_INPUT_INVALID"):
                load_json_object(path)

    def test_password_mode_binds_auth_mode_and_requires_null_keyfile(self):
        from standalone_controller import build_config

        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            raw = self._fixture(root)
            raw["ssh_auth_mode"] = "password"
            raw["ssh_key_file"] = None
            config_path, authorization_path, authorization = self._write_pair(root, raw)
            config = build_config(raw, authorization)
            self.assertEqual(authorization["ssh_auth_mode"], "password")
            self.assertIsNone(config.ssh_key_file)
            self.assertNotIn("password", authorization)
            self.assertNotIn("ssh_password", raw)
            from n2_controller import validate_local
            validate_local(config)

    def test_password_mode_rejects_keyfile_and_auth_mode_mismatch(self):
        from standalone_controller import build_config

        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            raw = self._fixture(root)
            raw["ssh_auth_mode"] = "password"
            with self.assertRaisesRegex(ValueError, "CONTROLLER_PASSWORD_KEYFILE_FORBIDDEN"):
                build_config(raw, {})

            raw["ssh_key_file"] = None
            config_path, authorization_path, authorization = self._write_pair(root, raw)
            authorization["ssh_auth_mode"] = "private_key"
            authorization_path.write_text(json.dumps(authorization), encoding="utf-8")
            with patch("standalone_controller._require_password_tty"):
                with self.assertRaisesRegex(ValueError, "AUTHORIZATION_MISMATCH:ssh_auth_mode"):
                    run_standalone(config_path, authorization_path, connect_factory=lambda **kwargs: None)
            self.assertFalse((root / "consumed").exists())

    def test_password_connector_passes_secret_only_to_paramiko_in_memory(self):
        from standalone_controller import build_config, paramiko_connector

        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            raw = self._fixture(root)
            raw["ssh_auth_mode"] = "password"
            raw["ssh_key_file"] = None
            config = build_config(raw, {})
            calls = {}

            class FakeClient:
                def load_host_keys(self, path):
                    calls["known_hosts"] = path

                def set_missing_host_key_policy(self, policy):
                    calls["policy"] = policy

                def connect(self, **kwargs):
                    calls["connect"] = kwargs

                def close(self):
                    calls["closed"] = True

            fake_paramiko = SimpleNamespace(SSHClient=FakeClient, RejectPolicy=lambda: "reject")
            with patch.dict(sys.modules, {"paramiko": fake_paramiko}), \
                    patch("standalone_controller._password_from_tty", return_value="memory-only-secret"):
                connect = paramiko_connector(config)
                connect(hostname=config.connect_host, username=config.target_user,
                        ssh_auth_mode="password", key_filename=None, timeout=20,
                        banner_timeout=20, auth_timeout=30)

            self.assertEqual(calls["connect"]["password"], "memory-only-secret")
            self.assertNotIn("key_filename", calls["connect"])
            self.assertFalse(calls["connect"]["allow_agent"])
            self.assertFalse(calls["connect"]["look_for_keys"])
            self.assertEqual(calls["policy"], "reject")
            self.assertNotIn("memory-only-secret", json.dumps(raw))

    def test_private_key_connector_still_uses_bound_key_and_disables_agent_lookup(self):
        from standalone_controller import build_config, paramiko_connector

        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            raw = self._fixture(root)
            config = build_config(raw, {})
            calls = {}

            class FakeClient:
                def load_host_keys(self, path):
                    calls["known_hosts"] = path

                def set_missing_host_key_policy(self, policy):
                    calls["policy"] = policy

                def connect(self, **kwargs):
                    calls["connect"] = kwargs

                def close(self):
                    calls["closed"] = True

            fake_paramiko = SimpleNamespace(SSHClient=FakeClient, RejectPolicy=lambda: "reject")
            with patch.dict(sys.modules, {"paramiko": fake_paramiko}):
                connect = paramiko_connector(config)
                connect(hostname=config.connect_host, username=config.target_user,
                        ssh_auth_mode="private_key", key_filename=str(config.ssh_key_file), timeout=20,
                        banner_timeout=20, auth_timeout=30)

            self.assertEqual(calls["connect"]["key_filename"], str(config.ssh_key_file))
            self.assertNotIn("password", calls["connect"])
            self.assertFalse(calls["connect"]["allow_agent"])
            self.assertFalse(calls["connect"]["look_for_keys"])
            self.assertEqual(calls["policy"], "reject")

    def test_password_mode_refuses_without_tty_before_authorization_claim(self):
        with tempfile.TemporaryDirectory() as temp:
            root = pathlib.Path(temp)
            raw = self._fixture(root)
            raw["ssh_auth_mode"] = "password"
            raw["ssh_key_file"] = None
            config_path, authorization_path, _ = self._write_pair(root, raw)
            calls = []
            with patch("standalone_controller._require_password_tty",
                       side_effect=RuntimeError("SSH_PASSWORD_TTY_REQUIRED")):
                with self.assertRaisesRegex(RuntimeError, "SSH_PASSWORD_TTY_REQUIRED"):
                    run_standalone(config_path, authorization_path,
                                   connect_factory=lambda **kwargs: calls.append(kwargs))
            self.assertEqual(calls, [])
            self.assertFalse((root / "consumed").exists())
            self.assertFalse((root / "evidence").exists())

    def test_password_getpass_refuses_non_tty_and_echo_fallback(self):
        from getpass import GetPassWarning
        from standalone_controller import _password_from_tty

        with patch("standalone_controller.sys.stdin") as stdin, \
                patch("standalone_controller.sys.stderr") as stderr, \
                patch("standalone_controller.getpass.getpass") as getpass_mock:
            stdin.isatty.return_value = False
            stderr.isatty.return_value = True
            with self.assertRaisesRegex(RuntimeError, "SSH_PASSWORD_TTY_REQUIRED"):
                _password_from_tty()
            getpass_mock.assert_not_called()

        with patch("standalone_controller.sys.stdin") as stdin, \
                patch("standalone_controller.sys.stderr") as stderr, \
                patch("standalone_controller.getpass.getpass", side_effect=GetPassWarning("fallback")):
            stdin.isatty.return_value = True
            stderr.isatty.return_value = True
            with self.assertRaisesRegex(RuntimeError, "SSH_PASSWORD_ECHO_FALLBACK_REFUSED"):
                _password_from_tty()

    def test_float_exponent_overflow_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            path = pathlib.Path(temp) / "overflow.json"
            path.write_text('{"wall_seconds":1e400}', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "JSON_INPUT_INVALID"):
                load_json_object(path)


if __name__ == "__main__":
    unittest.main()
