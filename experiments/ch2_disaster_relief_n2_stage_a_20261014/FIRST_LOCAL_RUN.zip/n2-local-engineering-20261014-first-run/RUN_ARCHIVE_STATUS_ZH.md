# 首次本地真实工程运行归档（2026-10-14）

7个t8合法候选（包含NOOP），同窗NOOP配对、C1延续。实际12次WM Adam更新、48次真实民用PPO更新；WM下一更新等价、PPO严格恢复等价。完整原始分支记录、rollouts、learning curves、模型及优化器checkpoint、worker与外watchdog收据均保存在run/。

来源代码逐项与运行收据所记SHA256一致后保存至frozen-source/。本地profile和独立R5限定准入也保存。运行文件未被修订或重提。

本包仅本地工程证据，尚待R6独立复核；不代表阶段A通过、Linux托管验收通过、正式研究预测门或组合收益。Windows cgroup指标不可测；收据末写资源未知与output planned bytes少估缺陷保留。当前模型heads仍缺未满足需求、改派增量和其他订单新增过期；critic归一化及零初始化仍待修。正式研究预算未冻结。

watchdog报告wall约105.786s、完整父+worker CPU约108.906s、RSS峰406495232 bytes；运行后实际文件总字节与planned计量有小差异，原收据不覆盖。按最终本包manifest复算字节；未超512MiB，不抹去计量缺陷。
