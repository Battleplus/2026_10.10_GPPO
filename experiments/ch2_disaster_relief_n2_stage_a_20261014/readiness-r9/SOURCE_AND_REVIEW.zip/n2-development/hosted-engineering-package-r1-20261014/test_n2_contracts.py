from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
CIVIL = ROOT / "references" / "civil"
sys.path.insert(0, str(CIVIL))
sys.path.insert(0, str(ROOT))

from relief_env import ReliefEnv
from ppo_trainer import compute_gae
from n2_contracts import LabelLeaf, canonical_digest, preaction_snapshot, public_candidate_features, restore_preaction, verify_preaction
from run_local_engineering import _require_hosted_runtime, managed_worker


FIXTURE = Path(r"E:\Z博士\development\ch2_disaster_relief_n01_v1\package\registered_data\data\train\graph-v1-train-combined-00.json")


class N2ContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.scenario = json.loads(FIXTURE.read_text(encoding="utf-8"))

    def setUp(self):
        self.env = ReliefEnv(self.scenario)
        self.env.reset("C1")
        self.snapshot = preaction_snapshot(self.env, "engineering-parent", 0, "window-0")

    def test_dynamic_catalog_identity_and_features(self):
        self.assertEqual(len(self.snapshot["candidate_keys"]), 17)
        self.assertEqual(self.snapshot["candidate_keys"][-1]["candidate_id"], "NOOP")
        verify_preaction(self.snapshot, self.env.public_observation(), self.env.candidates())
        features = [public_candidate_features(self.env.public_observation(), c) for c in self.env.candidates()]
        self.assertEqual(len(features), 17)
        self.assertEqual(features[-1], {"action_noop": 1.0})
        self.assertNotIn("true_tasks", self.snapshot["PublicPrefix"])
        self.assertEqual(restore_preaction(self.snapshot).time, self.env.time)


class ManagedWorkerMappingTests(unittest.TestCase):
    def test_managed_worker_visits_all_stages_and_uses_verified_export(self):
        stages = (
            "input_admission", "paired_collection", "world_training_and_restore", "offline_prediction",
            "conditional_policy_training", "conditional_task_confirmation", "analysis_and_settlement",
            "settlement_and_verified_export",
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)

            class FakeRuntime:
                stage_order = stages

                def __init__(self):
                    self.work_root = root
                    self.visited = []
                    self.exports = []

                def select_stage(self, stage):
                    self.assert_stage = len(self.visited)
                    if stage != stages[self.assert_stage]:
                        raise AssertionError(f"unexpected stage: {stage}")
                    self.visited.append(stage)

                def export_verified(self, *, source, relative_path, expected_sha256, amounts):
                    import hashlib
                    self.assert_stage = len(self.visited)
                    if self.visited[-1] != stages[-1] or amounts != {"verified_exports": 1}:
                        raise AssertionError("verified export stage or amount mismatch")
                    destination = root / "verified" / relative_path
                    destination.parent.mkdir(parents=True, exist_ok=True)
                    destination.write_bytes(source.read_bytes())
                    actual = hashlib.sha256(destination.read_bytes()).hexdigest().upper()
                    if actual != expected_sha256.upper():
                        raise AssertionError("export digest mismatch")
                    record = {"path": relative_path, "sha256": actual}
                    self.exports.append(record)
                    return record

                def check_catalog_size(self, observed_including_noop):
                    if type(observed_including_noop) is not int or observed_including_noop < 1 or observed_including_noop > 128:
                        raise AssertionError("catalog cap mismatch")

            runtime = FakeRuntime()

            def fake_main(*, output_root, runtime):
                for stage in stages:
                    runtime.select_stage(stage)
                output_root.mkdir(parents=True, exist_ok=True)
                (output_root / "LOCAL_ENGINEERING_RECEIPT.json").write_text("{}\n", encoding="utf-8")
                (output_root / "branch_records.jsonl").write_text("{\"candidate\":\"c0\"}\n", encoding="utf-8")
                (output_root / "wm-checkpoint.pt").write_bytes(b"wm-checkpoint")
                (output_root / "ppo-rollout.jsonl").write_text("{\"transition\":1}\n", encoding="utf-8")
                runtime.check_catalog_size(7)
                return {"schema": "n2-local-engineering-run/1", "source_sha256": {}}

            with patch("run_local_engineering.main", side_effect=fake_main) as main:
                result = managed_worker(runtime)

            main.assert_called_once_with(output_root=root / "n2-local-engineering-output", runtime=runtime)
            self.assertEqual(runtime.visited, list(stages))
            self.assertEqual(len(runtime.exports), 1)
            self.assertEqual(result["verified_export"], runtime.exports[0])
            self.assertEqual(result["evidence_archive_sha256"], runtime.exports[0]["sha256"])
            archive = root / result["evidence_archive_path"]
            with zipfile.ZipFile(archive) as bundle:
                self.assertEqual(set(bundle.namelist()), {
                    "LOCAL_ENGINEERING_RECEIPT.json", "branch_records.jsonl", "wm-checkpoint.pt",
                    "ppo-rollout.jsonl", "evidence-index.json",
                })
                index = json.loads(bundle.read("evidence-index.json"))
                self.assertIn("wm-checkpoint.pt", index["artifact_sha256"])
                self.assertEqual(index["artifact_sha256"]["wm-checkpoint.pt"],
                                 __import__("hashlib").sha256(b"wm-checkpoint").hexdigest().upper())

    def test_host_runtime_admission_rejects_non_target_platform(self):
        with patch("run_local_engineering.platform.system", return_value="Windows"):
            with self.assertRaisesRegex(RuntimeError, "HOST_RUNTIME_ADMISSION_MISMATCH"):
                _require_hosted_runtime()

class N2ContractTestsContinuation(N2ContractTests):
    def test_candidate_order_is_not_identity(self):
        by_id = {row["id"]: public_candidate_features(self.env.public_observation(), row)
                 for row in self.env.candidates()}
        reversed_rows = list(reversed(self.env.candidates()))
        self.assertEqual(by_id, {row["id"]: public_candidate_features(self.env.public_observation(), row)
                                 for row in reversed_rows})
        verify_preaction(self.snapshot, self.env.public_observation(), reversed_rows)

    def test_post_action_observation_rejected(self):
        changed = copy.deepcopy(self.env)
        changed.step(["NOOP"])
        with self.assertRaisesRegex(ValueError, "PRE_POST_ACTION_MIXED"):
            verify_preaction(self.snapshot, changed.public_observation(), changed.candidates())

    def test_hidden_truth_changes_do_not_change_public_prefix_or_catalog(self):
        changed_scenario = copy.deepcopy(self.scenario)
        changed_scenario["tasks"].append({
            "id": "unreported-extra", "kind": "delivery", "known_initial": False,
            "local": True, "position": [1.0, 1.0], "priority": 1, "deadline": 20,
            "report_delay": 12, "commodity": "water", "quantity": 1,
            "depot_id": "depot-1", "load_minutes": 1, "unload_minutes": 1,
        })
        changed_scenario["disturbances"].extend([
            {"id": "future-failure", "kind": "failure", "platform_id": "uav-1", "time": 3, "report_delay": 5},
            {"id": "unreported-stock-change", "kind": "stock_loss", "depot_id": "depot-1", "commodity": "water", "quantity": 2, "time": 4, "report_delay": 6},
        ])
        changed = ReliefEnv(changed_scenario)
        changed.reset("C1")
        self.assertEqual(self.snapshot["context"]["public_prefix_sha256"],
                         canonical_digest(__import__("n2_contracts").public_prefix(changed.public_observation())))
        verify_preaction(self.snapshot, changed.public_observation(), changed.candidates())

    def test_cross_window_key_context_tampering_rejected(self):
        changed = copy.deepcopy(self.snapshot)
        changed["candidate_keys"][0]["window_id"] = "other-window"
        with self.assertRaisesRegex(ValueError, "CANDIDATE_KEY_CONTEXT_MISMATCH"):
            verify_preaction(changed, self.env.public_observation(), self.env.candidates())

    def test_duplicate_candidate_keys_are_rejected(self):
        changed = copy.deepcopy(self.snapshot)
        changed["candidate_keys"][1] = copy.deepcopy(changed["candidate_keys"][0])
        with self.assertRaisesRegex(ValueError, "CANDIDATE_KEY_BINDING_MISMATCH"):
            verify_preaction(changed, self.env.public_observation(), self.env.candidates())

    def test_saved_catalog_binding_is_checked(self):
        changed = copy.deepcopy(self.snapshot)
        changed["candidate_catalog"] = []
        with self.assertRaisesRegex(ValueError, "SAVED_CATALOG_BINDING_MISMATCH"):
            verify_preaction(changed, self.env.public_observation(), self.env.candidates())

    def test_context_time_is_bound_to_live_public_time(self):
        changed = copy.deepcopy(self.snapshot)
        changed["context"]["time"] = 999
        changed["candidate_keys"] = [{**key, "time": 999} for key in changed["candidate_keys"]]
        with self.assertRaisesRegex(ValueError, "SNAPSHOT_CONTEXT_TIME_MISMATCH"):
            verify_preaction(changed, self.env.public_observation(), self.env.candidates())

    def test_consumer_must_bind_window_identity(self):
        with self.assertRaisesRegex(ValueError, "SNAPSHOT_CONTEXT_MISMATCH"):
            verify_preaction(
                self.snapshot,
                self.env.public_observation(),
                self.env.candidates(),
                expected_context={"parent_id": "engineering-parent", "repeat": 0, "window_id": "other-window"},
            )

    def test_snapshot_mutation_rejected(self):
        changed = copy.deepcopy(self.snapshot)
        changed["PublicPrefix"]["time"] += 1
        with self.assertRaisesRegex(ValueError, "PUBLIC_PREFIX_BINDING_MISMATCH"):
            restore_preaction(changed)

    def test_unknown_cannot_be_silently_zero_filled(self):
        self.assertEqual(LabelLeaf(None, False, "branch_restore_failed").value, None)
        with self.assertRaisesRegex(ValueError, "UNKNOWN_LABEL_MUST_NOT_BE_ZERO_FILLED"):
            LabelLeaf(0.0, False, "")
        with self.assertRaisesRegex(ValueError, "VALID_LABEL_INCOMPLETE"):
            LabelLeaf(None, True, None)
        with self.assertRaisesRegex(ValueError, "VALID_LABEL_INCOMPLETE"):
            LabelLeaf(float("nan"), True, None)

    def test_duplicate_candidate_ids_rejected(self):
        changed = copy.deepcopy(self.env)
        catalog = changed.candidates()
        catalog[1] = dict(catalog[0])
        changed.candidates = lambda: catalog
        with self.assertRaisesRegex(ValueError, "CANDIDATE_IDENTITY_INVALID"):
            preaction_snapshot(changed, "engineering-parent", 0, "window-0")

    def test_terminal_and_truncation_bootstrap_are_distinct(self):
        terminal_adv, terminal_ret = compute_gae([1], [.5], [2], [True], [False], [False])
        trunc_adv, trunc_ret = compute_gae([1], [.5], [2], [False], [True], [False])
        self.assertAlmostEqual(float(terminal_adv[0]), .5, places=6)
        self.assertAlmostEqual(float(terminal_ret[0]), 1.0, places=6)
        self.assertAlmostEqual(float(trunc_adv[0]), 2.48, places=5)
        self.assertAlmostEqual(float(trunc_ret[0]), 2.98, places=5)

    def test_event_signal_valid_zero_one_and_unknown(self):
        sys.path.insert(0, str(ROOT / "references" / "world_model"))
        from event_signal_contract import validate
        self.assertEqual(validate({"event_signal": 0.0, "event_signal_valid": True}), (0.0, True))
        self.assertEqual(validate({"event_signal": 1.0, "event_signal_valid": True}), (1.0, True))
        with self.assertRaisesRegex(ValueError, "EVENT_SIGNAL_UNKNOWN"):
            validate({"event_signal": 0.0, "event_signal_valid": False})


if __name__ == "__main__":
    unittest.main()
