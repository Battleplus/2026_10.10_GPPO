from __future__ import annotations

import argparse
import copy
import hashlib
import json
import platform
import sys
import time
import zipfile
from pathlib import Path

import torch


ROOT = Path(__file__).resolve().parent
PROFILE_PATH = ROOT / "LOCAL_ENGINEERING_BUDGET.json"
PROFILE = json.loads(PROFILE_PATH.read_text(encoding="utf-8"))
ENGINEERING = ROOT / "references" / "existing_n2"
CIVIL = ROOT / "references" / "civil"
sys.path[:0] = [str(ROOT), str(ENGINEERING), str(CIVIL)]

from baselines import choose_step_c1_actions
from graph_policy import build_policy
from ppo_integration import CriticAugmentedPPOTrainer
from ppo_trainer import PPOTrainer, verify_next_update_equivalence
from relief_env import ReliefEnv
from references.existing_n2.tests.test_branching import opportunity_scenario
from branching import capture_snapshot, run_synthetic_candidate_pair
from world_model import (
    CriticAugmentedGraphPolicy,
    CriticOnlyGppoAdapter,
    DynamicConsequenceModel,
    EngineeringTrainer,
    public_branch_batch,
    public_policy_tensors,
    _tensor_state_digest,
)


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def canonical_digest(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest().upper()


def _require_hosted_runtime() -> dict:
    """Require the exact CPU-only hosted engineering runtime before work begins."""
    import numpy as np

    expected = {
        "platform": "Linux", "python": "3.11.16", "torch": "2.7.0+cu128", "numpy": "1.26.0",
        "torch_threads": 1, "torch_interop_threads": 1,
        "cuda_is_available": False, "cuda_is_initialized": False,
    }
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    actual = {
        "platform": platform.system(), "python": platform.python_version(), "torch": torch.__version__,
        "numpy": np.__version__, "torch_threads": torch.get_num_threads(),
        "torch_interop_threads": torch.get_num_interop_threads(),
        "cuda_is_available": bool(torch.cuda.is_available()),
        "cuda_is_initialized": bool(torch.cuda.is_initialized()),
    }
    if actual != expected:
        raise RuntimeError("HOST_RUNTIME_ADMISSION_MISMATCH:" + json.dumps({"expected": expected, "actual": actual}, sort_keys=True))
    return actual


def _write_evidence_archive(output: Path, source_hashes: dict[str, str]) -> Path:
    """Package raw branch/checkpoint/rollout artifacts and source identity."""
    archive = output / "n2-local-engineering-evidence.zip"
    files = sorted(path for path in output.rglob("*") if path.is_file() and path != archive)
    index = {
        "schema": "n2-local-engineering-evidence-index/1",
        "source_sha256": source_hashes,
        "artifact_sha256": {path.relative_to(output).as_posix(): sha256_file(path) for path in files},
    }
    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as stream:
        for path in files:
            stream.write(path, path.relative_to(output).as_posix())
        stream.writestr("evidence-index.json", json.dumps(index, sort_keys=True, ensure_ascii=True, indent=2) + "\n")
    return archive


def build_ppo(
    run_dir: Path, scenarios: list[dict], wm_state: dict[str, torch.Tensor],
    normalization_policy_input: dict, normalization_data_identity: str, model_hook=None,
) -> CriticAugmentedPPOTrainer:
    torch.manual_seed(901)
    base_policy = build_policy("L1", 8201)
    wm = DynamicConsequenceModel(5, 4, 5, hidden_dim=8)
    wm.load_state_dict(wm_state, strict=True)
    torch.manual_seed(271828)
    adapter = CriticOnlyGppoAdapter(hidden_dim=8)
    normalization_features, normalization_binding = public_policy_tensors(normalization_policy_input)
    with torch.no_grad():
        normalization_prediction = wm(
            normalization_features["context"], normalization_features["candidate_features"],
            normalization_features["task_features"], normalization_features["candidate_mask"],
            normalization_features["task_mask"], normalization_binding,
        )
        normalization_graph = __import__("graph_policy").encode_public_graph(normalization_policy_input)
        normalization_logits, _ = base_policy._graph_outputs(normalization_graph)
        normalization_probabilities = torch.softmax(normalization_logits, dim=-1).unsqueeze(0)
    if normalization_graph.candidate_ids != normalization_binding.candidate_ids[0]:
        raise RuntimeError("CRITIC_NORMALIZATION_CANDIDATE_ORDER")
    adapter.fit_training_normalization(
        [(normalization_prediction["continuous"][:, :, 0], normalization_probabilities,
          normalization_features["candidate_mask"])],
        training_manifest={
            "split": "train", "data_identity": normalization_data_identity,
            "window_ids": ["n2-local-engineering/t8"],
        },
    )
    policy = CriticAugmentedGraphPolicy(base_policy, adapter, wm)
    data_hash = canonical_digest(scenarios)
    trainer = CriticAugmentedPPOTrainer(
        policy, variant="L1", seed=8201, scenarios=scenarios,
        data_hash=data_hash, package_root=CIVIL, run_dir=run_dir,
        allow_engineering_scenarios=True,
    )
    trainer.optimizer._n2_kind = "ppo"
    if model_hook is not None:
        model_hook(trainer.policy.world_model, "ppo_critic")
    return trainer


def main(output_root: Path | None = None, runtime=None) -> dict:
    if output_root is None:
        parser = argparse.ArgumentParser()
        parser.add_argument("--output-root", type=Path, required=True)
        output_root = parser.parse_args().output_root
    output = output_root.resolve()
    output.mkdir(parents=True, exist_ok=False)
    output_writes = [0]
    output_root_text = str(output).casefold()
    if PROFILE.get("status") != "AUTHORIZED_LOCAL_ENGINEERING_ONLY":
        raise RuntimeError("LOCAL_PROFILE_STATUS_INVALID")
    profile_hash = sha256_file(PROFILE_PATH)
    source_files = sorted({
        ROOT / "n2_contracts.py", ROOT / "test_n2_contracts.py", PROFILE_PATH,
        Path(__file__).resolve(), ROOT / "run_local_engineering_watchdog.py",
        CIVIL / "fixtures" / "control.json",
        *[path for path in ENGINEERING.rglob("*.py") if "__pycache__" not in path.parts],
        *[path for path in CIVIL.rglob("*.py") if "__pycache__" not in path.parts],
    })
    source_hashes_before = {str(path.relative_to(ROOT)): sha256_file(path) for path in source_files}
    counters = {
        "environment_steps": 0, "steps_by_phase": {}, "episode_constructions": 0,
        "ppo_episodes": 0, "wm_optimizer_steps": 0, "ppo_optimizer_steps": 0,
        "checkpoint_reads": 0, "checkpoint_writes": 0, "wm_forwards": 0, "wm_candidate_rows": 0,
    }
    phase = ["input_admission"]

    def budgeted(name, amounts, function):
        if runtime is None:
            return function()
        return runtime.operation(stage=runtime.current_stage, name=name, amounts=amounts, function=function)

    def select_stage(stage, marker):
        if runtime is None:
            return
        runtime.select_stage(stage)
        runtime.operation(stage=stage, name=marker, amounts={}, function=lambda: None)

    def audit_io(event, values):
        if event == "open" and values:
            path = str(values[0]).casefold()
            mode = values[1] if len(values) > 1 else None
            if path.startswith(output_root_text) and isinstance(mode, str) and any(flag in mode for flag in "wax+"):
                output_writes[0] += 1
                if output_writes[0] > PROFILE["runtime"]["output_write_operations_max"]:
                    raise RuntimeError("LOCAL_OUTPUT_WRITE_CAP")
                budgeted("output_write_open", {"output_write_operations": 1}, lambda: None)
        elif event in {"os.rename", "os.remove"} and values:
            if any(str(value).casefold().startswith(output_root_text) for value in values[:2]):
                output_writes[0] += 1
                if output_writes[0] > PROFILE["runtime"]["output_write_operations_max"]:
                    raise RuntimeError("LOCAL_OUTPUT_WRITE_CAP")
                budgeted("output_tree_mutation", {"output_write_operations": 1}, lambda: None)
        elif event in {"subprocess.Popen", "os.system", "os.spawn", "os.fork", "os.forkpty", "os.posix_spawn"}:
            raise RuntimeError("LOCAL_WORKER_PROCESS_SPAWN_FORBIDDEN")

    sys.addaudithook(audit_io)
    original_env_init = ReliefEnv.__init__
    original_env_reset = ReliefEnv.reset
    original_env_step = ReliefEnv.step

    def counted_init(self, *values, **kwargs):
        counters["episode_constructions"] += 1
        if counters["episode_constructions"] > PROFILE["work_caps"]["episode_constructions_max"]:
            raise RuntimeError("EPISODE_CONSTRUCTION_CAP")
        return budgeted("episode_construction", {"episode_constructions": 1},
                        lambda: original_env_init(self, *values, **kwargs))

    def counted_reset(self, *values, **kwargs):
        if phase[0] == "ppo_critic":
            counters["ppo_episodes"] += 1
            if counters["ppo_episodes"] > PROFILE["work_caps"]["ppo_rollout_episodes_max"]:
                raise RuntimeError("PPO_ROLLOUT_EPISODE_CAP")
            return budgeted("ppo_rollout_episode", {"ppo_rollout_episodes": 1},
                            lambda: original_env_reset(self, *values, **kwargs))
        if phase[0] == "base_scan":
            return budgeted("base_rollout_episode", {"base_rollout_episodes": 1},
                            lambda: original_env_reset(self, *values, **kwargs))
        return original_env_reset(self, *values, **kwargs)

    def counted_step(self, *values, **kwargs):
        caps = PROFILE["work_caps"]
        phase_cap = {
            "base_scan": caps["base_rollout_steps_max"],
            "branches": caps["branch_steps_max"],
            "ppo_critic": caps["ppo_environment_steps_max"],
        }.get(phase[0])
        if counters["environment_steps"] >= caps["total_environment_steps_max"]:
            raise RuntimeError("TOTAL_ENVIRONMENT_STEP_CAP")
        if phase_cap is not None and counters["steps_by_phase"].get(phase[0], 0) >= phase_cap:
            raise RuntimeError(f"{phase[0].upper()}_ENVIRONMENT_STEP_CAP")
        counters["environment_steps"] += 1
        step_phase = phase[0]
        counters["steps_by_phase"][step_phase] = counters["steps_by_phase"].get(step_phase, 0) + 1
        return budgeted("environment_step", {"environment_steps": 1},
                        lambda: original_env_step(self, *values, **kwargs))

    original_policy_input = ReliefEnv.policy_input

    ReliefEnv.__init__, ReliefEnv.reset, ReliefEnv.step = counted_init, counted_reset, counted_step

    original_adam_step = torch.optim.Adam.step

    def counted_adam_step(self, *values, **kwargs):
        kind = getattr(self, "_n2_kind", None)
        if kind == "wm":
            cap = PROFILE["work_caps"]["wm_optimizer_steps_max"]
            key = "wm_optimizer_steps"
        elif kind == "ppo":
            cap = PROFILE["work_caps"]["ppo_optimizer_steps_max"]
            key = "ppo_optimizer_steps"
        else:
            return original_adam_step(self, *values, **kwargs)
        if counters[key] >= cap:
            raise RuntimeError(f"{key.upper()}_CAP")
        counters[key] += 1
        resource = "wm_optimizer_steps" if kind == "wm" else "ppo_optimizer_steps"
        return budgeted("optimizer_step", {resource: 1},
                        lambda: original_adam_step(self, *values, **kwargs))

    torch.optim.Adam.step = counted_adam_step

    def checkpoint_count(kind):
        counters[f"checkpoint_{kind}"] += 1
        if counters["checkpoint_reads"] + counters["checkpoint_writes"] > PROFILE["runtime"]["checkpoint_reads_and_writes_max"]:
            raise RuntimeError("CHECKPOINT_OPERATION_CAP")

    def wrap_checkpoint(cls, name, kind):
        original = getattr(cls, name)

        def wrapped(self, *values, **kwargs):
            checkpoint_count(kind)
            return budgeted("checkpoint_" + kind, {"checkpoint_io": 1},
                            lambda: original(self, *values, **kwargs))

        setattr(cls, name, wrapped)

    wrap_checkpoint(EngineeringTrainer, "save_checkpoint", "writes")
    wrap_checkpoint(EngineeringTrainer, "restore_checkpoint", "reads")
    wrap_checkpoint(PPOTrainer, "save_checkpoint", "writes")
    wrap_checkpoint(PPOTrainer, "restore_checkpoint", "reads")
    torch.set_num_threads(1)
    wall_start, cpu_start = time.perf_counter(), time.process_time()

    if runtime is not None:
        select_stage("input_admission", "input_admission_gate")
        runtime.operation(stage=runtime.current_stage, name="runtime_admission", amounts={}, function=_require_hosted_runtime)
    fixture_path = CIVIL / "fixtures" / "control.json"
    fixture = json.loads(fixture_path.read_text(encoding="utf-8"))
    scenario = opportunity_scenario(fixture)
    env = ReliefEnv(copy.deepcopy(scenario))
    if runtime is not None:
        select_stage("paired_collection", "paired_collection_gate")
    phase[0] = "base_scan"
    env.reset("C1")
    snapshot_json = None
    max_catalog = 0
    base_steps = 0
    while not env._terminal:
        observation = env.public_observation()
        candidates = env.candidates()
        if len(candidates) > PROFILE["work_caps"]["candidate_catalog_cap_including_noop"]:
            raise RuntimeError("COMPLETE_CATALOG_EXCEEDS_FROZEN_CAP")
        if runtime is not None:
            runtime.check_catalog_size(len(candidates))
        max_catalog = max(max_catalog, len(candidates))
        if env.time == 8:
            snapshot_json = capture_snapshot(env, parent_id="n2-local-engineering", repeat=0, window_id="t8")
        actions = choose_step_c1_actions(observation, candidates)
        env.step([item["id"] for item in actions] + ["NOOP"] if actions else ["NOOP"])
        base_steps += 1
    if snapshot_json is None:
        raise RuntimeError("T8_SNAPSHOT_NOT_CAPTURED")

    phase[0] = "branches"
    source = ReliefEnv(copy.deepcopy(scenario))
    source.reset("C1")
    for _ in range(8):
        observation = source.public_observation()
        actions = choose_step_c1_actions(observation, source.candidates())
        source.step([item["id"] for item in actions] + ["NOOP"] if actions else ["NOOP"])
    catalog = source.candidates()
    candidate_ids = [item["id"] for item in catalog]
    if len(candidate_ids) != len(set(candidate_ids)) or candidate_ids.count("NOOP") != 1:
        raise RuntimeError("COMPLETE_CATALOG_IDENTITY_INVALID")
    if len(candidate_ids) > PROFILE["work_caps"]["candidate_catalog_cap_including_noop"]:
        raise RuntimeError("BRANCH_CATALOG_CAP")
    records = [budgeted("paired_candidate_branch", {"branch_count": 1},
                        lambda candidate_id=candidate_id: run_synthetic_candidate_pair(snapshot_json, candidate_id))
               for candidate_id in candidate_ids]
    records_path = output / "branch_records.jsonl"
    with records_path.open("w", encoding="utf-8", newline="\n") as stream:
        for record in records:
            stream.write(json.dumps(record, sort_keys=True, ensure_ascii=True) + "\n")
    policy_input = source.policy_input()
    batch = public_branch_batch(
        policy_input, records, window_id=("n2-local-engineering", 0, "t8"),
    )

    torch.manual_seed(410)
    wm = DynamicConsequenceModel(5, 4, 5, hidden_dim=8)
    data_identity = canonical_digest({"fixture_sha256": sha256_file(fixture_path), "records": records})
    wm_trainer = EngineeringTrainer(wm, data_identity=data_identity)
    wm_trainer.optimizer._n2_kind = "wm"
    wm_trace = {"wm_train": 0, "resume_audit": 0, "inference": 0, "ppo_critic": 0}
    candidate_samples = {key: 0 for key in wm_trace}

    def count_forward(_module, inputs):
        rows = int(inputs[1].shape[0] * inputs[1].shape[1])
        if counters["wm_forwards"] >= PROFILE["work_caps"]["world_model_forwards_max"]:
            raise RuntimeError("WM_FORWARD_CAP")
        if counters["wm_candidate_rows"] + rows > PROFILE["work_caps"]["world_model_candidate_sample_evaluations_max"]:
            raise RuntimeError("WM_CANDIDATE_SAMPLE_CAP")
        wm_trace[phase[0]] += 1
        candidate_samples[phase[0]] += rows
        counters["wm_forwards"] += 1
        counters["wm_candidate_rows"] += rows
        budgeted("world_model_forward", {
            "world_model_forwards": 1,
            "world_model_candidate_sample_evaluations": rows,
        }, lambda: None)

    def attach_model_hook(model, name):
        model.register_forward_pre_hook(count_forward)

    if runtime is not None:
        select_stage("world_training_and_restore", "world_training_restore_gate")
    phase[0] = "wm_train"
    attach_model_hook(wm, "wm_train")
    wm_updates = [wm_trainer.update(batch) for _ in range(10)]
    wm_checkpoint = output / "wm-checkpoint.pt"
    wm_trainer.save_checkpoint(wm_checkpoint)
    restored_wm = DynamicConsequenceModel(5, 4, 5, hidden_dim=8)
    restored_wm_trainer = EngineeringTrainer(restored_wm, data_identity=data_identity)
    restored_wm_trainer.optimizer._n2_kind = "wm"
    attach_model_hook(restored_wm, "resume_audit")
    restored_wm_trainer.restore_checkpoint(wm_checkpoint)
    phase[0] = "resume_audit"
    wm_trainer.update(batch)
    restored_wm_trainer.update(batch)
    wm_equivalent = _tensor_state_digest(wm.state_dict()) == _tensor_state_digest(restored_wm.state_dict())
    if not wm_equivalent:
        raise RuntimeError("WM_NEXT_UPDATE_RESTORE_MISMATCH")
    wm_frozen_checkpoint = output / "wm-frozen-checkpoint.pt"
    wm_trainer.save_checkpoint(wm_frozen_checkpoint)
    if runtime is not None:
        select_stage("offline_prediction", "offline_prediction_gate")
    phase[0] = "inference"
    with torch.no_grad():
        inputs = batch["inputs"]
        wm(inputs["context"], inputs["candidate_features"], inputs["task_features"],
           inputs["candidate_mask"], inputs["task_mask"], inputs["binding"])

    scenarios = []
    for index in range(4):
        item = copy.deepcopy(scenario)
        item["scenario_id"] = f"n2-local-ppo-{index}"
        scenarios.append(item)
    if runtime is not None:
        select_stage("conditional_policy_training", "conditional_policy_training_gate")
    phase[0] = "ppo_critic"
    first = build_ppo(output / "ppo-original", scenarios, wm.state_dict(), policy_input, data_identity, attach_model_hook)
    first_result = first.train_round()
    checkpoint = Path(first_result["checkpoint"]["path"])
    equivalence = verify_next_update_equivalence(
        first, lambda: build_ppo(output / "ppo-restored", scenarios, wm.state_dict(), policy_input, data_identity, attach_model_hook), checkpoint,
    )
    if not equivalence.get("equivalent"):
        raise RuntimeError("PPO_NEXT_UPDATE_RESTORE_MISMATCH")

    if runtime is not None:
        select_stage("conditional_task_confirmation", "local_task_confirmation_gate")

    wm_forward_total = counters["wm_forwards"]
    wm_row_total = counters["wm_candidate_rows"]
    combined_ppo_updates = 3 * first_result["optimizer_updates"]
    combined_ppo_steps = 3 * first_result["transition_count"]
    branch_steps = counters["steps_by_phase"].get("branches", 0)
    if wm_trainer.update_index != 11 or restored_wm_trainer.update_index != 11:
        raise RuntimeError("WM_UPDATE_COUNT_MISMATCH")
    if (not (PROFILE["work_caps"]["wm_optimizer_steps_min"] <= counters["wm_optimizer_steps"]
             <= PROFILE["work_caps"]["wm_optimizer_steps_max"])
            or combined_ppo_updates < PROFILE["work_caps"]["ppo_optimizer_steps_min"]
            or combined_ppo_updates > PROFILE["work_caps"]["ppo_optimizer_steps_max"]
            or combined_ppo_updates != counters["ppo_optimizer_steps"]):
        raise RuntimeError("OPTIMIZER_STEP_CAP")
    if (wm_forward_total > PROFILE["work_caps"]["world_model_forwards_max"]
            or wm_row_total > PROFILE["work_caps"]["world_model_candidate_sample_evaluations_max"]
            or counters["environment_steps"] > PROFILE["work_caps"]["total_environment_steps_max"]):
        raise RuntimeError("COMPUTE_OPERATION_CAP")
    if (len(records) > PROFILE["work_caps"]["branch_count_max"]
            or len(candidate_ids) > PROFILE["work_caps"]["candidate_catalog_cap_including_noop"]):
        raise RuntimeError("BRANCH_OR_CATALOG_CAP")
    if output_writes[0] > PROFILE["runtime"]["output_write_operations_max"]:
        raise RuntimeError("OUTPUT_WRITE_CAP")
    if (counters["ppo_optimizer_steps"] < PROFILE["work_caps"]["ppo_optimizer_steps_min"]
            or counters["ppo_optimizer_steps"] > PROFILE["work_caps"]["ppo_optimizer_steps_max"]):
        raise RuntimeError("PPO_OPTIMIZER_STEP_COUNT")

    source_hashes_after = {str(path.relative_to(ROOT)): sha256_file(path) for path in source_files}
    if source_hashes_after != source_hashes_before or sha256_file(PROFILE_PATH) != profile_hash:
        raise RuntimeError("LOCAL_SOURCE_OR_PROFILE_CHANGED_DURING_RUN")
    if runtime is not None:
        select_stage("analysis_and_settlement", "local_analysis_settlement_gate")
    report = {
        "schema": "n2-local-engineering-run/1",
        "scope": "local synthetic engineering only; no study evidence or formal training",
        "runtime": {"python": platform.python_version(), "torch": torch.__version__, "device": "cpu",
                    "worker_process_metrics": "local process timing only; authoritative hosted cgroup settlement is supervisor-owned"},
        "budget": {"profile": str(PROFILE_PATH), "sha256": profile_hash},
        "input": {"fixture": str(fixture_path), "fixture_sha256": sha256_file(fixture_path), "base_episode_steps": base_steps, "base_full_catalog_max_including_noop": max_catalog},
        "branch": {"time": 8, "candidate_count_including_noop": len(candidate_ids), "candidate_ids": candidate_ids,
                   "branch_count": len(records), "reference": "same-window NOOP; both branches then frozen C1 continuation",
                   "continuation_steps_max": max(record["horizon_minutes"] for record in records),
                   "environment_steps": branch_steps},
        "world_model": {"optimizer_steps_across_both_paths": counters["wm_optimizer_steps"], "forward_counts_by_phase": wm_trace,
                        "candidate_rows_by_phase": candidate_samples,
                        "checkpoint_writes": counters["checkpoint_writes"], "checkpoint_reads": counters["checkpoint_reads"],
                        "next_update_equivalent": wm_equivalent, "checkpoint_sha256": sha256_file(wm_checkpoint),
                        "final_frozen_wm_sha256": _tensor_state_digest(wm.state_dict()),
                        "final_frozen_checkpoint_sha256": sha256_file(wm_frozen_checkpoint)},
        "ppo": {"variant": "civilian L1 actor with trained frozen WM critic adapter", "round1_transitions": first_result["transition_count"],
                "round1_optimizer_updates": first_result["optimizer_updates"], "restore_equivalence": equivalence,
                "combined_optimizer_updates_across_comparison_paths": counters["ppo_optimizer_steps"],
                "combined_environment_transitions_across_comparison_paths": counters["steps_by_phase"].get("ppo_critic", 0),
                "forward_counts_by_phase": {"ppo_critic": wm_trace["ppo_critic"]},
                "candidate_rows": candidate_samples["ppo_critic"]},
        "source_sha256": source_hashes_before,
        "measurement": {"wall_seconds_including_checkpoints": time.perf_counter() - wall_start,
                        "total_environment_steps": counters["environment_steps"],
                        "environment_steps_by_phase": counters["steps_by_phase"],
                        "episode_constructions": counters["episode_constructions"],
                        "ppo_episodes": counters["ppo_episodes"],
                        "process_cpu_seconds_including_checkpoints": time.process_time() - cpu_start,
                        "optimizer_steps_actual": {"wm": counters["wm_optimizer_steps"], "ppo": counters["ppo_optimizer_steps"]},
                        "checkpoint_operations_actual": {"reads": counters["checkpoint_reads"], "writes": counters["checkpoint_writes"]},
                        "audited_output_write_operations": output_writes[0],
                        "output_file_count": sum(1 for path in output.rglob("*") if path.is_file()),
                        "output_tree_bytes": sum(path.stat().st_size for path in output.rglob("*") if path.is_file())},
        "limitations": ["Worker timing covers worker-local calls; supervisor cgroup accounting includes archive creation, verified export, and settlement.",
                        "The receipt covers one synthetic fixture and does not establish research effectiveness or generalization.",
                        "Global reward labels use the copied civilian simulator reward semantics as an engineering proxy."],
    }
    report_path = output / "LOCAL_ENGINEERING_RECEIPT.json"
    report_path.write_text(json.dumps(report, sort_keys=True, ensure_ascii=True, indent=2) + "\n", encoding="utf-8")
    if runtime is not None:
        select_stage("settlement_and_verified_export", "verified_export_pending")
    print(json.dumps({"receipt": str(report_path), "wm_steps": report["world_model"]["optimizer_steps_across_both_paths"],
                      "ppo_updates": report["ppo"]["round1_optimizer_updates"],
                      "candidate_count": len(candidate_ids), "measurement": report["measurement"]}, sort_keys=True))
    return report


def managed_worker(runtime) -> dict:
    """Run local synthetic engineering through the managed stage ledger."""
    expected = (
        "input_admission", "paired_collection", "world_training_and_restore", "offline_prediction",
        "conditional_policy_training", "conditional_task_confirmation", "analysis_and_settlement",
        "settlement_and_verified_export",
    )
    if runtime.stage_order != expected:
        raise RuntimeError("MANAGED_STAGE_ORDER_MISMATCH")
    output = runtime.work_root / "n2-local-engineering-output"
    report = main(output_root=output, runtime=runtime)
    receipt = output / "LOCAL_ENGINEERING_RECEIPT.json"
    archive = _write_evidence_archive(output, report["source_sha256"])
    export_record = runtime.export_verified(
        source=archive,
        relative_path="n2-local-engineering/n2-local-engineering-evidence.zip",
        expected_sha256=sha256_file(archive),
        amounts={"verified_exports": 1},
    )
    return {
        "scope": "local synthetic engineering only; no study evidence or formal training",
        "receipt_path": receipt.relative_to(runtime.work_root).as_posix(),
        "receipt_sha256": sha256_file(receipt),
        "evidence_archive_path": archive.relative_to(runtime.work_root).as_posix(),
        "evidence_archive_sha256": sha256_file(archive),
        "verified_export": export_record,
        "stage_order": list(runtime.stage_order),
        "engineering_receipt_schema": report["schema"],
    }


if __name__ == "__main__":
    main()
