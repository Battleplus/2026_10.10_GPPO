"""Unique entry for preflight, authorization, and durable systemd handoff."""
import argparse
import hashlib
import json
import os
import platform
import re
import secrets
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FORMAL_ATTEMPT = "w1-drone-consequence-ranking-window-balanced-ablation-v7-input-reuse-stage-schedule-repair-once"
FORMAL_MODE = "ranking_normalization_ablation"
ENGINEERING_MODE = "systemd_handoff_engineering_acceptance"
ENGINEERING_WORKERS = {
    "acceptance/handoff_worker.py",
    "acceptance/ranking_worker_schedule_runner.py",
}


def sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _identity():
    identity = _read_json(ROOT / "frozen-identity.json")
    manifest_path = ROOT / "execution-manifest.json"
    hashes_path = ROOT / "hashes.json"
    request_path = ROOT / "RESOURCE_REQUEST.json"
    manifest_hash = sha256(manifest_path)
    hashes_hash = sha256(hashes_path)
    request_hash = sha256(request_path)
    if (identity.get("manifest_sha256") != manifest_hash
            or identity.get("hashes_sha256") != hashes_hash
            or identity.get("request_sha256") != request_hash):
        raise SystemExit("FROZEN_IDENTITY_DIGEST_REJECTED")
    hashes = _read_json(hashes_path)
    excluded = {"execution-manifest.json", "hashes.json", "frozen-identity.json"}
    actual_files = {}
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if "__pycache__" in path.parts or path.suffix in {".pyc", ".pyo"}:
            raise SystemExit("BYTECODE_PRESENT:" + str(path.relative_to(ROOT)))
        relative = path.relative_to(ROOT).as_posix()
        if relative not in excluded:
            actual_files[relative] = path
    if set(actual_files) != set(hashes["files"]):
        raise SystemExit("FROZEN_FILE_SET_MISMATCH")
    for relative, expected in hashes["files"].items():
        if sha256(actual_files[relative]) != expected:
            raise SystemExit("FROZEN_FILE_SHA256:" + relative)
    manifest = _read_json(manifest_path)
    request = _read_json(request_path)
    matrix = _read_json(ROOT / "experiment-matrix.json")
    attempt = matrix.get("attempt")
    if not attempt or any(item.get("attempt") != attempt for item in (identity, manifest, hashes, request)):
        raise SystemExit("FROZEN_ATTEMPT_BINDING_REJECTED")
    mode = matrix.get("research_mode")
    if mode == FORMAL_MODE:
        if attempt != FORMAL_ATTEMPT or request.get("gppo_continuation") is not False:
            raise SystemExit("FORMAL_RESEARCH_IDENTITY_REJECTED")
    elif mode == ENGINEERING_MODE:
        if (not matrix.get("controlled_acceptance")
                or not attempt.startswith("engineering-")
                or request.get("research_mode") != ENGINEERING_MODE
                or request.get("gppo_continuation") is not False
                or matrix.get("controlled_worker") not in ENGINEERING_WORKERS):
            raise SystemExit("ENGINEERING_IDENTITY_REJECTED")
    else:
        raise SystemExit("RESEARCH_MODE_REJECTED")
    return identity, manifest_hash, hashes_hash, request_hash, matrix, request


def verify_frozen_identity():
    return _identity()[:4]


def _check_runtime():
    if platform.python_version() != "3.11.16" or not sys.platform.startswith("linux"):
        raise SystemExit("REQUIRES_FROZEN_LINUX_PYTHON_3_11_16")
    import numpy
    import torch
    if torch.__version__ != "2.7.0+cu128" or numpy.__version__ != "1.26.0":
        raise SystemExit("FROZEN_RUNTIME_VERSION_MISMATCH")
    if 0 not in os.sched_getaffinity(0):
        raise SystemExit("CPU0_UNAVAILABLE")
    if torch.cuda.is_initialized():
        raise SystemExit("GPU_MUST_REMAIN_UNINITIALIZED")
    return torch, numpy


def preflight():
    _identity()
    torch, numpy = _check_runtime()
    if (ROOT / "run-once").exists() or (ROOT / "authorization.json").exists():
        raise SystemExit("PREFLIGHT_FORMAL_ARTIFACT_PRESENT")
    acceptance_env = _clean_environment(acceptance=True)
    result = subprocess.run([sys.executable, "-B", str(ROOT / "acceptance" / "ranking_reduction_acceptance.py")],
                            cwd=ROOT, env=acceptance_env, check=True, capture_output=True, text=True)
    print(json.dumps({"status": "preflight_pass", "attempt": FORMAL_ATTEMPT,
        "manifest_sha256": sha256(ROOT / "execution-manifest.json"),
        "hashes_sha256": sha256(ROOT / "hashes.json"),
        "request_sha256": sha256(ROOT / "RESOURCE_REQUEST.json"),
        "runtime": {"python": platform.python_version(), "torch": torch.__version__,
                    "numpy": numpy.__version__, "cpu0_available": True,
                    "cuda_initialized": torch.cuda.is_initialized()},
        "formal_attempt_created": False, "token_created": False,
        "acceptance": json.loads(result.stdout)}, sort_keys=True))


def _clean_environment(*, acceptance=False):
    """Construct all variables used by the launch chain; never inherit W1 state."""
    env = {
        "HOME": os.environ.get("HOME", str(Path.home())),
        "USER": os.environ.get("USER", ""),
        "LOGNAME": os.environ.get("LOGNAME", os.environ.get("USER", "")),
        "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
        "LANG": os.environ.get("LANG", "C.UTF-8"),
        "XDG_RUNTIME_DIR": os.environ.get("XDG_RUNTIME_DIR", ""),
        "DBUS_SESSION_BUS_ADDRESS": os.environ.get("DBUS_SESSION_BUS_ADDRESS", ""),
        "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1",
        "PYTHONHASHSEED": "0",
        "PYTHONUNBUFFERED": "1",
        "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "W1_VERIFIED_ATTEMPT": "",
        "W1_PHASE_ACCOUNTING_SOCKET": "",
        "W1_LOCAL_STAGING_WALL_SECONDS": "0",
        "W1_LOCAL_STAGING_CPU_SECONDS": "0",
    }
    if acceptance:
        env["CUDA_VISIBLE_DEVICES"] = ""
    return env


def _authorization(auth_path):
    path = Path(auth_path).resolve()
    if path == ROOT or ROOT in path.parents:
        raise SystemExit("AUTHORIZATION_MUST_REMAIN_OUTSIDE_PACKAGE")
    if not path.is_file():
        raise SystemExit("AUTHORIZATION_FILE_MISSING")
    auth = _read_json(path)
    identity, manifest_hash, hashes_hash, request_hash, matrix, request = _identity()
    if (auth.get("authorization_verified") is not True
            or auth.get("attempt") != matrix["attempt"]
            or auth.get("manifest_sha256") != manifest_hash
            or auth.get("hashes_sha256") != hashes_hash
            or auth.get("request_sha256") != request_hash
            or auth.get("one_time_token") is None
            or not isinstance(auth.get("one_time_token"), str)
            or not auth["one_time_token"].strip()):
        raise SystemExit("AUTHORIZATION_IDENTITY_REJECTED")
    return path, auth, identity, manifest_hash, hashes_hash, request_hash, matrix, request


def _claim_path(auth_path, attempt):
    return auth_path.parent / (attempt + ".handoff-claim.json")


def _write_exclusive(path, payload):
    data = json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8") + b"\n"
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    fd = os.open(path, flags, 0o600)
    try:
        with os.fdopen(fd, "wb", closefd=False) as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
    finally:
        os.close(fd)
    directory_fd = os.open(path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _unit_name(attempt):
    return attempt + ".service"


def _systemd_seconds(value):
    text = value.strip()
    if text in {"infinity", "∞"}:
        return float("inf")
    units = {"us": 1e-6, "usec": 1e-6,
             "ms": 1e-3, "msec": 1e-3, "s": 1.0, "sec": 1.0,
             "min": 60.0, "h": 3600.0, "d": 86400.0, "w": 604800.0}
    token = re.compile(r"([0-9]+(?:\.[0-9]+)?)(usec|us|msec|ms|sec|min|s|h|d|w)")
    matches = list(token.finditer(text))
    if not matches:
        raise ValueError("SYSTEMD_TIMESPAN_UNPARSEABLE:" + text)
    cursor = 0
    total = 0.0
    for match in matches:
        if text[cursor:match.start()].strip():
            raise ValueError("SYSTEMD_TIMESPAN_UNPARSEABLE:" + text)
        total += float(match.group(1)) * units[match.group(2)]
        cursor = match.end()
    if text[cursor:].strip():
        raise ValueError("SYSTEMD_TIMESPAN_UNPARSEABLE:" + text)
    return total


def _systemd_run(auth_path, claim_path, nonce, attempt, request):
    unit = _unit_name(attempt)
    runtime_max = int(request.get("controller_limits", {}).get(
        "systemd_RuntimeMaxSec", request["totals"]["wall_seconds"] + 30))
    log_dir = Path.home() / ".local" / "state" / "w1-pilot" / "handoff-logs"
    log_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
    stdout_path = log_dir / (attempt + ".stdout.log")
    stderr_path = log_dir / (attempt + ".stderr.log")
    if stdout_path.exists() or stderr_path.exists():
        raise SystemExit("HANDOFF_LOG_ALREADY_EXISTS")
    fixed = {
        "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1",
        "PYTHONHASHSEED": "0", "PYTHONNOUSERSITE": "1", "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",
        "W1_VERIFIED_ATTEMPT": "", "W1_PHASE_ACCOUNTING_SOCKET": "",
        "W1_LOCAL_STAGING_WALL_SECONDS": "0", "W1_LOCAL_STAGING_CPU_SECONDS": "0",
        "W1_WORLD_MODEL_DEVICE": "", "W1_ALLOCATED_GPU_PHYSICAL_DEVICE": "",
    }
    caller_env = _clean_environment()
    for key in ("HOME", "USER", "LOGNAME", "PATH", "LANG", "XDG_RUNTIME_DIR",
                "DBUS_SESSION_BUS_ADDRESS"):
        fixed[key] = caller_env.get(key, "")
    command = ["systemd-run", "--user", "--no-block", "--quiet",
        "--unit", unit, "--working-directory", str(ROOT),
        "--property=Restart=no", "--property=KillMode=control-group",
        "--property=RuntimeMaxSec=" + str(runtime_max),
        "--property=StandardOutput=append:" + str(stdout_path),
        "--property=StandardError=append:" + str(stderr_path)]
    command.extend("--setenv=" + key + "=" + value for key, value in fixed.items())
    command.extend([sys.executable, "-B", str(ROOT / "launch_pilot.py"),
                    "--service", "--authorization", str(auth_path),
                    "--handoff-claim", str(claim_path), "--handoff-nonce", nonce,
                    "--unit", unit])
    result = subprocess.run(command, cwd=ROOT, env=_clean_environment(),
                            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE, text=True, check=False, timeout=20)
    if result.returncode:
        raise SystemExit("SYSTEMD_HANDOFF_REJECTED:" + result.stderr.strip())
    check = subprocess.run(["systemctl", "--user", "show", unit, "--no-page",
        "--property=Restart", "--property=KillMode", "--property=RuntimeMaxUSec",
        "--property=ExecStart", "--property=Environment", "--property=StandardOutput",
        "--property=StandardError"], cwd=ROOT, env=_clean_environment(),
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, check=False, timeout=10)
    if check.returncode:
        raise SystemExit("SYSTEMD_UNIT_INSPECTION_FAILED:" + check.stderr.strip())
    properties = dict(line.split("=", 1) for line in check.stdout.splitlines() if "=" in line)
    observed_runtime = _systemd_seconds(properties.get("RuntimeMaxUSec", ""))
    if (properties.get("Restart") != "no" or properties.get("KillMode") != "control-group"
            or abs(observed_runtime - runtime_max) > 1e-6
            or properties.get("StandardOutput") != "append"
            or properties.get("StandardError") != "append"
            or "W1_VERIFIED_ATTEMPT=" not in properties.get("Environment", "")
            or "W1_LOCAL_STAGING_WALL_SECONDS=0" not in properties.get("Environment", "")
            or "W1_LOCAL_STAGING_CPU_SECONDS=0" not in properties.get("Environment", "")):
        raise SystemExit("SYSTEMD_RUNTIME_CONFIGURATION_MISMATCH")
    if "W1_PHASE_ACCOUNTING_SOCKET=" not in properties.get("Environment", ""):
        raise SystemExit("SYSTEMD_PHASE_SOCKET_MUST_START_EMPTY")
    return unit, properties, stdout_path, stderr_path


def _service(auth_path, claim_path, nonce, unit):
    auth_path, auth, _identity_doc, manifest_hash, hashes_hash, request_hash, matrix, request = _authorization(auth_path)
    claim_path = Path(claim_path).resolve()
    if claim_path != _claim_path(auth_path, matrix["attempt"]):
        raise SystemExit("HANDOFF_CLAIM_PATH_REJECTED")
    if _unit_name(matrix["attempt"]) != unit:
        raise SystemExit("SYSTEMD_UNIT_IDENTITY_REJECTED")
    claim = _read_json(claim_path)
    if (claim.get("attempt") != matrix["attempt"] or claim.get("unit") != unit
            or claim.get("nonce_sha256") != hashlib.sha256(nonce.encode()).hexdigest()
            or claim.get("authorization_sha256") != sha256(auth_path)
            or claim.get("manifest_sha256") != manifest_hash
            or claim.get("hashes_sha256") != hashes_hash
            or claim.get("request_sha256") != request_hash):
        raise SystemExit("HANDOFF_CLAIM_REJECTED")
    if (os.environ.get("W1_VERIFIED_ATTEMPT", "") != ""
            or os.environ.get("W1_PHASE_ACCOUNTING_SOCKET", "") != ""
            or os.environ.get("W1_LOCAL_STAGING_WALL_SECONDS") != "0"
            or os.environ.get("W1_LOCAL_STAGING_CPU_SECONDS") != "0"):
        raise SystemExit("SYSTEMD_ENVIRONMENT_SANITIZATION_FAILED")
    invocation = os.environ.get("INVOCATION_ID")
    if not invocation:
        raise SystemExit("SYSTEMD_INVOCATION_ID_MISSING")
    shown = subprocess.run(["systemctl", "--user", "show", unit, "--no-page",
        "--property=InvocationID", "--property=Restart", "--property=KillMode",
        "--property=RuntimeMaxUSec", "--property=Environment", "--property=StandardOutput",
        "--property=StandardError"], stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, text=True, check=False, timeout=10)
    if shown.returncode:
        raise SystemExit("SYSTEMD_SELF_INSPECTION_FAILED")
    properties = dict(line.split("=", 1) for line in shown.stdout.splitlines() if "=" in line)
    runtime_max = int(request.get("controller_limits", {}).get(
        "systemd_RuntimeMaxSec", request["totals"]["wall_seconds"] + 30))
    observed_runtime = _systemd_seconds(properties.get("RuntimeMaxUSec", ""))
    if (properties.get("InvocationID") != invocation or properties.get("Restart") != "no"
            or properties.get("KillMode") != "control-group"
            or abs(observed_runtime - runtime_max) > 1e-6
            or properties.get("StandardOutput") != "append"
            or properties.get("StandardError") != "append"):
        raise SystemExit("SYSTEMD_UNIT_SELF_CONFIGURATION_REJECTED")
    expected_env = {"OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1", "NUMEXPR_NUM_THREADS": "1",
        "PYTHONHASHSEED": "0", "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1", "W1_VERIFIED_ATTEMPT": "",
        "W1_PHASE_ACCOUNTING_SOCKET": "", "W1_LOCAL_STAGING_WALL_SECONDS": "0",
        "W1_LOCAL_STAGING_CPU_SECONDS": "0", "W1_WORLD_MODEL_DEVICE": "",
        "W1_ALLOCATED_GPU_PHYSICAL_DEVICE": "", "CUDA_VISIBLE_DEVICES": ""}
    for key, value in expected_env.items():
        if os.environ.get(key) != value:
            raise SystemExit("SYSTEMD_SERVICE_ENVIRONMENT_MISMATCH:" + key)
    os.environ.update({"W1_VERIFIED_ATTEMPT": matrix["attempt"],
        "W1_PHASE_ACCOUNTING_SOCKET": "", "W1_LOCAL_STAGING_WALL_SECONDS": "0",
        "W1_LOCAL_STAGING_CPU_SECONDS": "0", "PYTHONDONTWRITEBYTECODE": "1",
        "PYTHONHASHSEED": "0", "PYTHONUNBUFFERED": "1", "CUDA_VISIBLE_DEVICES": "",
        "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
        "NUMEXPR_NUM_THREADS": "1"})
    receipt = claim_path.with_suffix(".service-receipt.json")
    if receipt.exists():
        raise SystemExit("HANDOFF_SERVICE_ALREADY_ENTERED")
    _write_exclusive(receipt, {"status": "service_verified", "attempt": matrix["attempt"],
        "unit": unit, "invocation_id": invocation, "verified_attempt_source": "authorization_and_frozen_identity",
        "verified_attempt": matrix["attempt"], "manifest_sha256": manifest_hash,
        "hashes_sha256": hashes_hash, "request_sha256": request_hash,
        "restart": properties["Restart"], "kill_mode": properties["KillMode"],
        "runtime_max_systemd": properties["RuntimeMaxUSec"],
        "runtime_max_seconds": observed_runtime,
        "standard_output": properties["StandardOutput"],
        "standard_error": properties["StandardError"],
        "systemd_environment": properties.get("Environment", ""),
        "environment_contract": expected_env,
        "systemd_received_caller_attempt": "empty", "formal_attempt_created_by_preflight": False})
    payload = json.dumps(auth, sort_keys=True).encode("utf-8")
    if matrix["research_mode"] == ENGINEERING_MODE:
        runner = matrix.get("controlled_worker")
        if runner not in ENGINEERING_WORKERS:
            raise SystemExit("ENGINEERING_WORKER_IDENTITY_REJECTED")
    else:
        runner = "ranking_ablation_worker.py"
    from supervise import main as supervise_main
    code = supervise_main(root=ROOT, runner=runner, worker_input=payload)
    raise SystemExit(code)


def formal(auth_path):
    _check_runtime()
    raw_path = Path(auth_path).resolve()
    if raw_path == ROOT or ROOT in raw_path.parents:
        raise SystemExit("AUTHORIZATION_MUST_REMAIN_OUTSIDE_PACKAGE")
    if raw_path.is_file():
        try:
            raw_attempt = _read_json(raw_path).get("attempt")
        except BaseException:
            raw_attempt = None
        if isinstance(raw_attempt, str) and raw_attempt:
            existing_claim = _claim_path(raw_path, raw_attempt)
            if existing_claim.exists():
                raise SystemExit("ATTEMPT_HANDOFF_ALREADY_CLAIMED")
    auth_path, auth, _identity_doc, manifest_hash, hashes_hash, request_hash, matrix, request = _authorization(auth_path)
    if matrix["research_mode"] == ENGINEERING_MODE:
        runner = matrix.get("controlled_worker")
        if runner not in ENGINEERING_WORKERS:
            raise SystemExit("ENGINEERING_WORKER_IDENTITY_REJECTED")
    elif matrix["research_mode"] == FORMAL_MODE and matrix["attempt"] == FORMAL_ATTEMPT:
        runner = "ranking_ablation_worker.py"
    else:
        raise SystemExit("AUTHORIZATION_MODE_REJECTED")
    claim_path = _claim_path(auth_path, matrix["attempt"])
    if any((ROOT / name).exists() for name in ("run-once", "execution.lock", "supervisor-status.json")):
        raise SystemExit("ATTEMPT_ALREADY_CONSUMED")
    nonce = secrets.token_urlsafe(32)
    claim = {"schema": "w1-systemd-handoff-claim/1", "status": "submitted",
        "attempt": matrix["attempt"], "unit": _unit_name(matrix["attempt"]),
        "nonce_sha256": hashlib.sha256(nonce.encode()).hexdigest(),
        "authorization_sha256": sha256(auth_path), "manifest_sha256": manifest_hash,
        "hashes_sha256": hashes_hash, "request_sha256": request_hash,
        "created_unix": time.time(), "runner": runner, "automatic_retry": False}
    try:
        _write_exclusive(claim_path, claim)
    except FileExistsError:
        raise SystemExit("ATTEMPT_HANDOFF_ALREADY_CLAIMED")
    unit, properties, stdout_path, stderr_path = _systemd_run(
        auth_path, claim_path, nonce, matrix["attempt"], request)
    submission = {"status": "persistent_handoff", "attempt": matrix["attempt"],
        "unit": unit, "manifest_sha256": manifest_hash, "hashes_sha256": hashes_hash,
        "request_sha256": request_hash, "systemd_properties": properties,
        "stdout_path": str(stdout_path), "stderr_path": str(stderr_path),
        "handoff_claim_path": str(claim_path), "worker_started_by_launcher": False,
        "completion_confirmed": False}
    print(json.dumps(submission, sort_keys=True))


def main():
    parser = argparse.ArgumentParser()
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--preflight", action="store_true")
    group.add_argument("--authorization")
    parser.add_argument("--service", action="store_true")
    parser.add_argument("--handoff-claim")
    parser.add_argument("--handoff-nonce")
    parser.add_argument("--unit")
    args = parser.parse_args()
    if args.preflight:
        if args.service or args.handoff_claim or args.handoff_nonce or args.unit:
            raise SystemExit("PREFLIGHT_ARGUMENT_MISMATCH")
        preflight()
    elif args.service:
        if not (args.handoff_claim and args.handoff_nonce and args.unit):
            raise SystemExit("SERVICE_HANDOFF_ARGUMENTS_REQUIRED")
        _service(args.authorization, args.handoff_claim, args.handoff_nonce, args.unit)
    else:
        if args.handoff_claim or args.handoff_nonce or args.unit:
            raise SystemExit("CALLER_CANNOT_SUPPLY_SERVICE_HANDOFF_FIELDS")
        formal(args.authorization)


if __name__ == "__main__":
    main()
