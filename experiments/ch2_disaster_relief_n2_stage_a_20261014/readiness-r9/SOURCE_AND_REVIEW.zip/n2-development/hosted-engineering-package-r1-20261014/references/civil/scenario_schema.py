"""Validation and loading for the synthetic disaster-relief schema.

The validator deliberately does not normalize or mutate its input.  The
engine makes its own copy after validation and supplies defaults for optional
kind-specific fields.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "relief-engineering/1"


def _fail(message: str) -> None:
    raise ValueError(message)


def _dict(value: Any, path: str) -> dict:
    if type(value) is not dict:
        _fail(f"{path} must be an object")
    return value


def _known_keys(value: dict, path: str, allowed: set[str]) -> None:
    if any(type(key) is not str for key in value):
        _fail(f"{path} field names must be strings")
    unknown = set(value) - allowed
    if unknown:
        _fail(f"{path} contains unknown fields: {sorted(unknown)}")


def _list(value: Any, path: str) -> list:
    if type(value) is not list:
        _fail(f"{path} must be an array")
    return value


def _string(value: Any, path: str, *, nonempty: bool = True) -> str:
    if type(value) is not str or (nonempty and not value.strip()):
        _fail(f"{path} must be a non-empty string")
    return value


def _bool(value: Any, path: str) -> bool:
    if type(value) is not bool:
        _fail(f"{path} must be boolean")
    return value


def _number(value: Any, path: str, *, minimum: float | None = None, positive: bool = False) -> float:
    if type(value) not in (int, float) or isinstance(value, bool) or not math.isfinite(float(value)):
        _fail(f"{path} must be finite numeric")
    result = float(value)
    if positive and result <= 0:
        _fail(f"{path} must be positive")
    if minimum is not None and result < minimum:
        _fail(f"{path} must be >= {minimum}")
    return result


def _integer(value: Any, path: str, *, minimum: int | None = None, positive: bool = False) -> int:
    if type(value) is not int or isinstance(value, bool):
        _fail(f"{path} must be an integer")
    if positive and value <= 0:
        _fail(f"{path} must be positive")
    if minimum is not None and value < minimum:
        _fail(f"{path} must be >= {minimum}")
    return value


def _position(value: Any, path: str) -> None:
    values = _list(value, path)
    if len(values) != 2:
        _fail(f"{path} must have two coordinates")
    _number(values[0], path + "[0]")
    _number(values[1], path + "[1]")


def _unique_ids(items: list[dict], path: str) -> set[str]:
    ids: set[str] = set()
    for index, item in enumerate(items):
        current = _dict(item, f"{path}[{index}]")
        ident = _string(current.get("id"), f"{path}[{index}].id")
        if ident in ids:
            _fail(f"duplicate id {ident!r} in {path}")
        ids.add(ident)
    return ids


def validate_scenario(scenario: dict) -> None:
    """Validate a schema-v1 scenario and raise ``ValueError`` on failure."""

    root = _dict(scenario, "scenario")
    _known_keys(root, "scenario", {
        "schema_version", "scenario_id", "synthetic", "units", "map", "horizon", "dt",
        "platforms", "depots", "tasks", "chapter1_snapshot", "disturbances",
    })
    if root.get("schema_version") != SCHEMA_VERSION:
        _fail(f"schema_version must be {SCHEMA_VERSION!r}")
    _string(root.get("scenario_id"), "scenario_id")
    if root.get("synthetic") is not True:
        _fail("synthetic must be true")

    units = _dict(root.get("units"), "units")
    _known_keys(units, "units", {"distance", "time", "quantity", "energy"})
    for key, expected in (("distance", "km"), ("time", "min"), ("quantity", "kg"), ("energy", "synthetic_unit")):
        if units.get(key) != expected:
            _fail(f"units.{key} must be {expected!r}")

    map_data = _dict(root.get("map"), "map")
    _known_keys(map_data, "map", {"rows", "cols", "cell_km", "local_block"})
    _integer(map_data.get("rows"), "map.rows", positive=True)
    _integer(map_data.get("cols"), "map.cols", positive=True)
    _number(map_data.get("cell_km"), "map.cell_km", positive=True)
    block = _list(map_data.get("local_block"), "map.local_block")
    if len(block) != 4:
        _fail("map.local_block must be [x, y, width, height]")
    for i, value in enumerate(block):
        _integer(value, f"map.local_block[{i}]")
    if block[2] <= 0 or block[3] <= 0:
        _fail("map.local_block width and height must be positive")
    if block[0] < 0 or block[1] < 0 or block[0] + block[2] > map_data["cols"] or block[1] + block[3] > map_data["rows"]:
        _fail("map.local_block outside map")

    horizon = _integer(root.get("horizon"), "horizon", positive=True)
    if root.get("dt") != 1:
        _fail("dt must be 1")

    platforms = _list(root.get("platforms"), "platforms")
    platform_ids = _unique_ids(platforms, "platforms")
    allowed_types = {"uav", "helicopter"}
    allowed_caps = {"inspect", "deliver"}
    for i, platform in enumerate(platforms):
        path = f"platforms[{i}]"
        _known_keys(platform, path, {
            "id", "type", "position", "local", "capabilities", "capacity_kg", "speed_km_min",
            "energy_initial", "energy_per_km", "service_energy_per_min",
        })
        _position(platform.get("position"), path + ".position")
        if platform.get("type") not in allowed_types:
            _fail(f"{path}.type must be uav or helicopter")
        _bool(platform.get("local"), path + ".local")
        caps = _list(platform.get("capabilities"), path + ".capabilities")
        if not caps or any(cap not in allowed_caps for cap in caps) or len(set(caps)) != len(caps):
            _fail(f"{path}.capabilities contains an unknown or duplicate capability")
        _number(platform.get("capacity_kg"), path + ".capacity_kg", minimum=0)
        _number(platform.get("speed_km_min"), path + ".speed_km_min", positive=True)
        _number(platform.get("energy_initial"), path + ".energy_initial", minimum=0)
        _number(platform.get("energy_per_km"), path + ".energy_per_km", minimum=0)
        _number(platform.get("service_energy_per_min"), path + ".service_energy_per_min", minimum=0)

    depots = _list(root.get("depots"), "depots")
    depot_ids = _unique_ids(depots, "depots")
    for i, depot in enumerate(depots):
        path = f"depots[{i}]"
        _known_keys(depot, path, {"id", "position", "stock"})
        _position(depot.get("position"), path + ".position")
        stock = _dict(depot.get("stock"), path + ".stock")
        for commodity, quantity in stock.items():
            _string(commodity, path + ".stock key")
            _number(quantity, path + ".stock." + commodity, minimum=0)

    tasks = _list(root.get("tasks"), "tasks")
    task_ids = _unique_ids(tasks, "tasks")
    task_by_id = {task["id"]: task for task in tasks}
    for i, task in enumerate(tasks):
        path = f"tasks[{i}]"
        _known_keys(task, path, {
            "id", "kind", "position", "local", "known_initial", "deadline", "priority",
            "discovered_by", "report_delay", "service_minutes", "commodity", "quantity",
            "depot_id", "load_minutes", "unload_minutes",
        })
        kind = task.get("kind")
        if kind not in {"inspection", "delivery"}:
            _fail(f"{path}.kind must be inspection or delivery")
        _position(task.get("position"), path + ".position")
        _bool(task.get("local"), path + ".local")
        task_x, task_y = task["position"]
        cell_km = float(map_data["cell_km"])
        local_x, local_y, local_width, local_height = block
        in_local_block = (
            local_x * cell_km <= task_x < (local_x + local_width) * cell_km
            and local_y * cell_km <= task_y < (local_y + local_height) * cell_km
        )
        if task["local"] != in_local_block:
            _fail(f"{path}.local does not match its position in map.local_block")
        _bool(task.get("known_initial"), path + ".known_initial")
        deadline = _integer(task.get("deadline"), path + ".deadline", positive=True)
        if deadline > horizon:
            _fail(f"{path}.deadline exceeds horizon")
        _number(task.get("priority"), path + ".priority", positive=True)
        discovered = task.get("discovered_by")
        if discovered is not None and discovered not in task_ids:
            _fail(f"{path}.discovered_by references an unknown task")
        if discovered is not None and task_by_id[discovered].get("kind") != "inspection":
            _fail(f"{path}.discovered_by must reference an inspection")
        if task.get("known_initial") and discovered is not None:
            _fail(f"{path}.known_initial cannot be true with discovered_by")
        _integer(task.get("report_delay", 0), path + ".report_delay", minimum=0)
        if kind == "inspection":
            _integer(task.get("service_minutes"), path + ".service_minutes", positive=True)
            if "commodity" in task and task["commodity"] is not None:
                _string(task["commodity"], path + ".commodity")
            if "quantity" in task and task["quantity"] is not None:
                _number(task["quantity"], path + ".quantity", positive=True)
        else:
            _string(task.get("commodity"), path + ".commodity")
            _number(task.get("quantity"), path + ".quantity", positive=True)
            depot_id = _string(task.get("depot_id"), path + ".depot_id")
            if depot_id not in depot_ids:
                _fail(f"{path}.depot_id references an unknown depot")
            _integer(task.get("load_minutes"), path + ".load_minutes", positive=True)
            _integer(task.get("unload_minutes"), path + ".unload_minutes", positive=True)

    snapshot = _dict(root.get("chapter1_snapshot"), "chapter1_snapshot")
    _known_keys(snapshot, "chapter1_snapshot", {"source", "time", "queues"})
    if snapshot.get("source") != "synthetic_initial_assignment" or type(snapshot.get("time")) is not int or snapshot.get("time") != 0:
        _fail("chapter1_snapshot source/time invalid")
    queues = _dict(snapshot.get("queues"), "chapter1_snapshot.queues")
    queued_ids: set[str] = set()
    for platform_id, queue in queues.items():
        if platform_id not in platform_ids:
            _fail(f"chapter1_snapshot references unknown platform {platform_id!r}")
        queue_values = _list(queue, f"chapter1_snapshot.queues.{platform_id}")
        for task_id in queue_values:
            if task_id not in task_ids:
                _fail(f"chapter1_snapshot references unknown task {task_id!r}")
            if task_id in queued_ids:
                _fail(f"task {task_id!r} appears in more than one initial queue")
            queued_ids.add(task_id)
            task = task_by_id[task_id]
            if not task["known_initial"]:
                _fail(f"hidden task {task_id!r} cannot be in chapter1_snapshot")
    # An initial queue can contain a task only when the platform can perform it.
    for platform_id, queue in queues.items():
        platform = next(item for item in platforms if item["id"] == platform_id)
        for task_id in queue:
            task = task_by_id[task_id]
            needed = "inspect" if task["kind"] == "inspection" else "deliver"
            if needed not in platform["capabilities"]:
                _fail(f"initial platform {platform_id!r} lacks {needed} capability")
            if task["local"] != platform["local"]:
                _fail(f"task {task_id!r} and initial platform {platform_id!r} have incompatible locality")

    disturbances = _list(root.get("disturbances", []), "disturbances")
    _unique_ids(disturbances, "disturbances")
    for i, disturbance in enumerate(disturbances):
        path = f"disturbances[{i}]"
        _known_keys(disturbance, path, {
            "id", "time", "kind", "report_delay", "platform_id", "value", "depot_id",
            "commodity", "quantity",
        })
        time = _integer(disturbance.get("time"), path + ".time", minimum=0)
        if time > horizon:
            _fail(f"{path}.time exceeds horizon")
        kind = disturbance.get("kind")
        if kind not in {"failure", "energy_change", "stock_loss"}:
            _fail(f"{path}.kind is invalid")
        _integer(disturbance.get("report_delay", 0), path + ".report_delay", minimum=0)
        if kind in {"failure", "energy_change"}:
            platform_id = _string(disturbance.get("platform_id"), path + ".platform_id")
            if platform_id not in platform_ids:
                _fail(f"{path}.platform_id references unknown platform")
            if kind == "energy_change":
                _number(disturbance.get("value"), path + ".value", minimum=0)
        else:
            depot_id = _string(disturbance.get("depot_id"), path + ".depot_id")
            if depot_id not in depot_ids:
                _fail(f"{path}.depot_id references unknown depot")
            _string(disturbance.get("commodity"), path + ".commodity")
            _number(disturbance.get("quantity"), path + ".quantity", positive=True)
def load_scenario(path: str | Path) -> dict:
    """Load a UTF-8 JSON scenario and validate it."""

    source = Path(path)
    try:
        with source.open("r", encoding="utf-8") as handle:
            scenario = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"unable to load scenario {source}: {exc}") from exc
    validate_scenario(scenario)
    return scenario
