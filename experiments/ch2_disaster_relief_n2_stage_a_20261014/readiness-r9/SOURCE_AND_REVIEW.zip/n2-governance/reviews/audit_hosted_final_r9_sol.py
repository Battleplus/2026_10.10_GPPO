"""Independent bounded hosted-source audit; never imports or executes training."""
from __future__ import annotations

import ast
import hashlib
import json
import sys
import tempfile
import zipfile
from pathlib import Path

BASE = Path('E:/10.14')
PACKAGE = BASE / 'n2-development/hosted-engineering-package-r1-20261014'
CONTROLLER = Path(sys.argv[1]) if len(sys.argv) > 1 else BASE / 'n2-development/controller'
PROPOSAL = BASE / 'n2-development/hosted-engineering-budget-proposal-r1-20261014.json'
CONFIG = BASE / 'n2-development/hosted-preparation-evidence/controller-config-proposed-r9-20261014.json'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def main():
    manifest = json.loads((PACKAGE / 'manifest.json').read_text(encoding='utf-8'))
    proposal = json.loads(PROPOSAL.read_text(encoding='utf-8'))
    config = json.loads(CONFIG.read_text(encoding='utf-8'))
    snapshot_path = CONTROLLER.with_name(CONTROLLER.name + '-SNAPSHOT_SHA256.json')
    snapshot = json.loads(snapshot_path.read_text(encoding='utf-8'))
    controller_observed = {p.relative_to(CONTROLLER).as_posix(): digest(p) for p in CONTROLLER.rglob('*') if p.is_file()}
    canonical = lambda value: hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('utf-8')).hexdigest().upper()
    bundle_names = {'managed_stage_supervisor.py', 'managed_runtime.py', 'managed_worker_entry.py', 'vendor/PROVENANCE.json'} | {p.relative_to(CONTROLLER).as_posix() for p in (CONTROLLER / 'vendor').glob('*.py')}
    bundle = canonical({name: controller_observed[name] for name in bundle_names})
    files = manifest['files']
    observed = {p.relative_to(PACKAGE).as_posix() for p in PACKAGE.rglob('*') if p.is_file()}
    expected = set(files) | set(manifest['metadata_files'])
    wrong = [p for p in files if not (PACKAGE / p).is_file() or digest(PACKAGE / p) != manifest['file_sha256'].get(p)]
    records = ''.join(f'{p}={digest(PACKAGE / p)}\n' for p in sorted(files) if (PACKAGE / p).is_file())
    content = hashlib.sha256(records.encode('utf-8')).hexdigest().upper()
    guards = manifest['managed_runtime']['guard_limits']
    request = manifest['managed_runtime']['resource_request']
    sources = list(PACKAGE.rglob('*.py')) + [p for p in CONTROLLER.glob('*.py')] + list((CONTROLLER / 'vendor').glob('*.py'))
    names = {p.stem for p in sources}
    known = set(sys.stdlib_module_names) | names | {'torch', 'numpy', 'psutil', 'paramiko', 'references', 'vendor'}
    unresolved = {}
    for path in sources:
        tree = ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
        imports = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split('.')[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module and not node.level:
                imports.add(node.module.split('.')[0])
            elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == '__import__' and node.args and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str):
                imports.add(node.args[0].value.split('.')[0])
        missing = sorted(imports - known)
        if missing:
            unresolved[str(path.relative_to(BASE))] = missing
    # Execute only the archive helper, extracted from AST. The inputs are tiny
    # synthetic raw files, never prior engineering results or a training run.
    worker_tree = ast.parse((PACKAGE / 'run_local_engineering.py').read_text(encoding='utf-8'))
    selected = [n for n in worker_tree.body if isinstance(n, ast.FunctionDef) and n.name in {'sha256_file', '_write_evidence_archive'}]
    namespace = {'Path': Path, 'hashlib': hashlib, 'zipfile': zipfile, 'json': json}
    exec(compile(ast.fix_missing_locations(ast.Module(body=selected, type_ignores=[])), '<archive-helper-only>', 'exec'), namespace)
    with tempfile.TemporaryDirectory(prefix='r9-sol-archive-') as temporary:
        output = Path(temporary)
        raw = {'branch_records.jsonl': b'{"synthetic": true}\n', 'wm-checkpoint.pt': b'synthetic-checkpoint', 'ppo-original/rollout.jsonl': b'{"synthetic": true}\n'}
        for relative, payload in raw.items():
            target = output / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
        archive = namespace['_write_evidence_archive'](output, {'worker': digest(PACKAGE / 'run_local_engineering.py')})
        with zipfile.ZipFile(archive) as stream:
            index = json.loads(stream.read('evidence-index.json'))
            archive_raw_ok = all(stream.read(name) == payload and index['artifact_sha256'][name] == hashlib.sha256(payload).hexdigest().upper() for name, payload in raw.items())
            archive_names = sorted(stream.namelist())
    from collections import defaultdict
    summed = defaultdict(int)
    for stage in request['stages'].values():
        for resource, amount in stage.items():
            summed[resource] += amount
    source_hashes = {p.relative_to(BASE).as_posix(): digest(p) for p in sources}
    result = {
        'schema': 'n2-independent-hosted-final-source-audit/1',
        'reviewer': 'GPT-6.1 Sol high independent bounded audit',
        'scope': 'Static source/config/inventory audit and tiny extracted archive helper only; no training, SSH, StageServer, Linux or authorization execution.',
        'manifest_sha256': digest(PACKAGE / 'manifest.json'),
        'package_content_sha256_actual': content,
        'package_content_hash_matches': content == manifest['package_content_sha256'],
        'manifest_external_binding_matches': digest(PACKAGE / 'manifest.json') == proposal['package_manifest_sha256'] == proposal['manifest_digest_binding']['manifest_sha256'],
        'content_external_binding_matches': content == proposal['package_content_sha256'] == proposal['manifest_digest_binding']['content_sha256'],
        'inventory_missing': sorted(expected - observed),
        'inventory_extra': sorted(observed - expected),
        'file_hash_mismatches': wrong,
        'unresolved_static_imports': unresolved,
        'guard_mismatches': {key: {'manifest': guards.get(key), 'proposal': value} for key, value in proposal['budget'].items() if key in guards and guards[key] != value},
        'manifest_cpu_quota_matches_proposal': guards.get('cpu_quota_percent') == proposal['budget']['cpu_quota_percent'],
        'stage_sum_matches_totals': dict(summed) == request['totals'],
        'totals_match_external_caps': request['totals'] == proposal['caps'],
        'archive_tiny_raw_smoke': {'passed': archive_raw_ok, 'members': archive_names, 'does_not_establish_hosted_export': True},
        'source_sha256': source_hashes,
        'proposal_sha256': digest(PROPOSAL),
        'controller_path': str(CONTROLLER),
        'controller_snapshot_sha256_actual': canonical(controller_observed),
        'controller_snapshot_matches': controller_observed == snapshot['file_sha256'] and canonical(controller_observed) == snapshot['canonical_sha256_excluding_this_file'],
        'controller_sha256_matches': digest(CONTROLLER / 'n2_controller.py') == snapshot['controller_sha256'],
        'controller_bundle_sha256_actual': bundle,
        'controller_bundle_matches': bundle == snapshot['controller_bundle_sha256'],
        'controller_test_log_sha256_matches': digest(Path(snapshot['verification_log_path'])) == snapshot['verification_log_sha256'],
        'proposed_config_sha256': digest(CONFIG),
        'proposed_config_binding_matches': config['package_sha256'] == digest(PACKAGE / 'manifest.json') and config['expected_identity'] == proposal['identity'] and config['run_identity'] == proposal['fresh_run_identity'] and config['unit'] == proposal['systemd_unit'] and config['remote_root'] == proposal['remote_root'] and config['python'] == proposal['target']['python'] and config['target_host'] == proposal['target']['host'] and config['target_user'] == proposal['target']['user'] and config['connect_host'] == proposal['target']['connect_host'] and {k:v for k,v in config['budget'].items() if k != 'status'} == proposal['budget'],
        'proposed_config_approval_status': config['budget']['status'],
        'proposed_config_key_reference_unresolved': 'REQUIRES_VERIFIED_PRIVATE_KEY_PATH' in config['ssh_key_file'],
        'authorization_created_or_consumed': False,
        'static_import_note': 'Unresolved imports are confined to dormant references/infrastructure/supervise.py, used by legacy launch_pilot, outside managed_worker/controller-vendor call path. No claim that every copied legacy entry point is runnable.',
        'hosted_acceptance': 'NOT_RUN',
    }
    target = Path(__file__).with_name('audit_hosted_final_r9_sol_output.json')
    target.write_text(json.dumps(result, sort_keys=True, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'source_sha256'}, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
